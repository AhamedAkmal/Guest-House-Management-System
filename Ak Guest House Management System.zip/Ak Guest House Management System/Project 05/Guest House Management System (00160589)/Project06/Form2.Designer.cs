﻿namespace Project06
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.panel03 = new System.Windows.Forms.Panel();
            this.Pass_txt = new System.Windows.Forms.TextBox();
            this.panel01 = new System.Windows.Forms.Panel();
            this.user_txt = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.picgoog = new System.Windows.Forms.PictureBox();
            this.picface = new System.Windows.Forms.PictureBox();
            this.picuser1 = new System.Windows.Forms.PictureBox();
            this.picpass1 = new System.Windows.Forms.PictureBox();
            this.logo = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.picgoog)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picface)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picuser1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picpass1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.logo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 30;
            this.bunifuElipse1.TargetControl = this;
            // 
            // panel03
            // 
            this.panel03.BackColor = System.Drawing.Color.White;
            this.panel03.Location = new System.Drawing.Point(36, 214);
            this.panel03.Name = "panel03";
            this.panel03.Size = new System.Drawing.Size(250, 1);
            this.panel03.TabIndex = 42;
            this.panel03.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // Pass_txt
            // 
            this.Pass_txt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.Pass_txt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Pass_txt.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pass_txt.ForeColor = System.Drawing.Color.DimGray;
            this.Pass_txt.HideSelection = false;
            this.Pass_txt.Location = new System.Drawing.Point(73, 189);
            this.Pass_txt.Name = "Pass_txt";
            this.Pass_txt.Size = new System.Drawing.Size(213, 19);
            this.Pass_txt.TabIndex = 41;
            this.Pass_txt.TabStop = false;
            this.Pass_txt.Text = "Password";
            this.Pass_txt.Click += new System.EventHandler(this.txt_pass_Click);
            this.Pass_txt.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // panel01
            // 
            this.panel01.BackColor = System.Drawing.Color.White;
            this.panel01.Location = new System.Drawing.Point(36, 155);
            this.panel01.Name = "panel01";
            this.panel01.Size = new System.Drawing.Size(250, 1);
            this.panel01.TabIndex = 40;
            // 
            // user_txt
            // 
            this.user_txt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.user_txt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.user_txt.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.user_txt.ForeColor = System.Drawing.Color.DimGray;
            this.user_txt.HideSelection = false;
            this.user_txt.Location = new System.Drawing.Point(73, 130);
            this.user_txt.Name = "user_txt";
            this.user_txt.Size = new System.Drawing.Size(213, 19);
            this.user_txt.TabIndex = 38;
            this.user_txt.TabStop = false;
            this.user_txt.Text = "Username";
            this.user_txt.Click += new System.EventHandler(this.txt_username_Click);
            this.user_txt.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(73, 255);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(180, 40);
            this.button1.TabIndex = 45;
            this.button1.Text = "Sign In with Facebook";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(108, 380);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 16);
            this.label1.TabIndex = 49;
            this.label1.Text = "Or Sign In With";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.White;
            this.panel4.Location = new System.Drawing.Point(34, 400);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(260, 1);
            this.panel4.TabIndex = 46;
            // 
            // button2
            // 
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(289, 12);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(25, 25);
            this.button2.TabIndex = 51;
            this.button2.Text = "X";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // picgoog
            // 
            this.picgoog.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picgoog.Image = global::Project06.Properties.Resources.google_logo1;
            this.picgoog.Location = new System.Drawing.Point(134, 407);
            this.picgoog.Name = "picgoog";
            this.picgoog.Size = new System.Drawing.Size(44, 44);
            this.picgoog.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picgoog.TabIndex = 48;
            this.picgoog.TabStop = false;
            this.picgoog.Click += new System.EventHandler(this.picgoog_Click);
            // 
            // picface
            // 
            this.picface.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picface.Image = global::Project06.Properties.Resources.Facebooklogo2;
            this.picface.Location = new System.Drawing.Point(35, 407);
            this.picface.Name = "picface";
            this.picface.Size = new System.Drawing.Size(44, 44);
            this.picface.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picface.TabIndex = 47;
            this.picface.TabStop = false;
            this.picface.Click += new System.EventHandler(this.picface_Click);
            // 
            // picuser1
            // 
            this.picuser1.BackgroundImage = global::Project06.Properties.Resources.profile02;
            this.picuser1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.picuser1.Location = new System.Drawing.Point(35, 125);
            this.picuser1.Name = "picuser1";
            this.picuser1.Size = new System.Drawing.Size(24, 24);
            this.picuser1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picuser1.TabIndex = 44;
            this.picuser1.TabStop = false;
            // 
            // picpass1
            // 
            this.picpass1.BackgroundImage = global::Project06.Properties.Resources.Lock02;
            this.picpass1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picpass1.Location = new System.Drawing.Point(35, 184);
            this.picpass1.Name = "picpass1";
            this.picpass1.Size = new System.Drawing.Size(24, 24);
            this.picpass1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picpass1.TabIndex = 43;
            this.picpass1.TabStop = false;
            // 
            // logo
            // 
            this.logo.Image = global::Project06.Properties.Resources.Facebooklogo1;
            this.logo.Location = new System.Drawing.Point(134, 12);
            this.logo.Name = "logo";
            this.logo.Size = new System.Drawing.Size(64, 64);
            this.logo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.logo.TabIndex = 39;
            this.logo.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox2.Image = global::Project06.Properties.Resources.twit001;
            this.pictureBox2.Location = new System.Drawing.Point(226, 401);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(68, 51);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 66;
            this.pictureBox2.TabStop = false;
            // 
            // timer1
            // 
            this.timer1.Interval = 10;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Interval = 10;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick_1);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.ClientSize = new System.Drawing.Size(326, 481);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.picgoog);
            this.Controls.Add(this.picface);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.picuser1);
            this.Controls.Add(this.picpass1);
            this.Controls.Add(this.panel03);
            this.Controls.Add(this.Pass_txt);
            this.Controls.Add(this.panel01);
            this.Controls.Add(this.user_txt);
            this.Controls.Add(this.logo);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Form2";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picgoog)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picface)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picuser1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picpass1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.logo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private System.Windows.Forms.PictureBox picuser1;
        private System.Windows.Forms.PictureBox picpass1;
        private System.Windows.Forms.Panel panel03;
        private System.Windows.Forms.TextBox Pass_txt;
        private System.Windows.Forms.Panel panel01;
        private System.Windows.Forms.TextBox user_txt;
        private System.Windows.Forms.PictureBox logo;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.PictureBox picgoog;
        private System.Windows.Forms.PictureBox picface;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
    }
}