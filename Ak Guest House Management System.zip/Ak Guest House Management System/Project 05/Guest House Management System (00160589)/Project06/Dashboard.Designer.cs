﻿namespace Project06
{
    partial class Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Dashboard));
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.btnlogout = new System.Windows.Forms.Button();
            this.btnbooking = new System.Windows.Forms.Button();
            this.btncustomer = new System.Windows.Forms.Button();
            this.btnuser = new System.Windows.Forms.Button();
            this.btndashboard = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pnlnav = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.p24 = new System.Windows.Forms.Panel();
            this.room24 = new System.Windows.Forms.Label();
            this.panel65 = new System.Windows.Forms.Panel();
            this.panel66 = new System.Windows.Forms.Panel();
            this.p20 = new System.Windows.Forms.Panel();
            this.room20 = new System.Windows.Forms.Label();
            this.panel41 = new System.Windows.Forms.Panel();
            this.panel42 = new System.Windows.Forms.Panel();
            this.p23 = new System.Windows.Forms.Panel();
            this.room23 = new System.Windows.Forms.Label();
            this.panel68 = new System.Windows.Forms.Panel();
            this.panel69 = new System.Windows.Forms.Panel();
            this.p12 = new System.Windows.Forms.Panel();
            this.room12 = new System.Windows.Forms.Label();
            this.panel29 = new System.Windows.Forms.Panel();
            this.panel30 = new System.Windows.Forms.Panel();
            this.p21 = new System.Windows.Forms.Panel();
            this.room21 = new System.Windows.Forms.Label();
            this.panel71 = new System.Windows.Forms.Panel();
            this.panel72 = new System.Windows.Forms.Panel();
            this.p22 = new System.Windows.Forms.Panel();
            this.room22 = new System.Windows.Forms.Label();
            this.panel74 = new System.Windows.Forms.Panel();
            this.panel75 = new System.Windows.Forms.Panel();
            this.p16 = new System.Windows.Forms.Panel();
            this.room16 = new System.Windows.Forms.Label();
            this.panel44 = new System.Windows.Forms.Panel();
            this.panel45 = new System.Windows.Forms.Panel();
            this.p08 = new System.Windows.Forms.Panel();
            this.room8 = new System.Windows.Forms.Label();
            this.panel17 = new System.Windows.Forms.Panel();
            this.panel18 = new System.Windows.Forms.Panel();
            this.p19 = new System.Windows.Forms.Panel();
            this.room19 = new System.Windows.Forms.Label();
            this.panel47 = new System.Windows.Forms.Panel();
            this.panel48 = new System.Windows.Forms.Panel();
            this.p11 = new System.Windows.Forms.Panel();
            this.room11 = new System.Windows.Forms.Label();
            this.panel32 = new System.Windows.Forms.Panel();
            this.panel33 = new System.Windows.Forms.Panel();
            this.p17 = new System.Windows.Forms.Panel();
            this.room17 = new System.Windows.Forms.Label();
            this.panel50 = new System.Windows.Forms.Panel();
            this.panel51 = new System.Windows.Forms.Panel();
            this.p04 = new System.Windows.Forms.Panel();
            this.room4 = new System.Windows.Forms.Label();
            this.panel14 = new System.Windows.Forms.Panel();
            this.panel15 = new System.Windows.Forms.Panel();
            this.p18 = new System.Windows.Forms.Panel();
            this.room18 = new System.Windows.Forms.Label();
            this.panel53 = new System.Windows.Forms.Panel();
            this.panel54 = new System.Windows.Forms.Panel();
            this.p09 = new System.Windows.Forms.Panel();
            this.room9 = new System.Windows.Forms.Label();
            this.panel35 = new System.Windows.Forms.Panel();
            this.panel36 = new System.Windows.Forms.Panel();
            this.p15 = new System.Windows.Forms.Panel();
            this.room15 = new System.Windows.Forms.Label();
            this.panel56 = new System.Windows.Forms.Panel();
            this.panel57 = new System.Windows.Forms.Panel();
            this.p10 = new System.Windows.Forms.Panel();
            this.room10 = new System.Windows.Forms.Label();
            this.panel38 = new System.Windows.Forms.Panel();
            this.panel39 = new System.Windows.Forms.Panel();
            this.p13 = new System.Windows.Forms.Panel();
            this.room13 = new System.Windows.Forms.Label();
            this.panel59 = new System.Windows.Forms.Panel();
            this.panel60 = new System.Windows.Forms.Panel();
            this.p14 = new System.Windows.Forms.Panel();
            this.room14 = new System.Windows.Forms.Label();
            this.panel62 = new System.Windows.Forms.Panel();
            this.panel63 = new System.Windows.Forms.Panel();
            this.p07 = new System.Windows.Forms.Panel();
            this.room7 = new System.Windows.Forms.Label();
            this.panel20 = new System.Windows.Forms.Panel();
            this.panel21 = new System.Windows.Forms.Panel();
            this.p03 = new System.Windows.Forms.Panel();
            this.room3 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.p05 = new System.Windows.Forms.Panel();
            this.room5 = new System.Windows.Forms.Label();
            this.panel23 = new System.Windows.Forms.Panel();
            this.panel24 = new System.Windows.Forms.Panel();
            this.p01 = new System.Windows.Forms.Panel();
            this.room1 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.p06 = new System.Windows.Forms.Panel();
            this.room6 = new System.Windows.Forms.Label();
            this.panel26 = new System.Windows.Forms.Panel();
            this.panel27 = new System.Windows.Forms.Panel();
            this.p02 = new System.Windows.Forms.Panel();
            this.room2 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.Ava_lb = new System.Windows.Forms.Label();
            this.Book_lb = new System.Windows.Forms.Label();
            this.bunifuElipse2 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.bunifuElipse3 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.label6 = new System.Windows.Forms.Label();
            this.Cusnum_lbl = new System.Windows.Forms.Label();
            this.Booknum_lbl = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.bunifuElipse4 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.bunifuElipse5 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.bunifuElipse6 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.bunifuElipse7 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.bunifuElipse8 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.bunifuElipse9 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.bunifuElipse10 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.bunifuElipse11 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.bunifuElipse12 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.bunifuElipse13 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.bunifuElipse14 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.bunifuElipse15 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.bunifuElipse16 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.bunifuElipse17 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.bunifuElipse18 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.bunifuElipse19 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.bunifuElipse20 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.bunifuElipse21 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.bunifuElipse22 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.bunifuElipse23 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.bunifuElipse24 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.bunifuElipse25 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.bunifuElipse26 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.bunifuElipse27 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.freerooms_progress = new Guna.UI.WinForms.GunaCircleProgressBar();
            this.label12 = new System.Windows.Forms.Label();
            this.Avalbl1 = new System.Windows.Forms.Label();
            this.Ava_progress = new Guna.UI.WinForms.GunaProgressBar();
            this.book_progress = new Guna.UI.WinForms.GunaProgressBar();
            this.gunaElipse1 = new Guna.UI.WinForms.GunaElipse(this.components);
            this.gunaElipse2 = new Guna.UI.WinForms.GunaElipse(this.components);
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.CusIDcb = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.CusNametb = new System.Windows.Forms.TextBox();
            this.btn_book = new Bunifu.Framework.UI.BunifuThinButton2();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel3.SuspendLayout();
            this.p24.SuspendLayout();
            this.panel65.SuspendLayout();
            this.p20.SuspendLayout();
            this.panel41.SuspendLayout();
            this.p23.SuspendLayout();
            this.panel68.SuspendLayout();
            this.p12.SuspendLayout();
            this.panel29.SuspendLayout();
            this.p21.SuspendLayout();
            this.panel71.SuspendLayout();
            this.p22.SuspendLayout();
            this.panel74.SuspendLayout();
            this.p16.SuspendLayout();
            this.panel44.SuspendLayout();
            this.p08.SuspendLayout();
            this.panel17.SuspendLayout();
            this.p19.SuspendLayout();
            this.panel47.SuspendLayout();
            this.p11.SuspendLayout();
            this.panel32.SuspendLayout();
            this.p17.SuspendLayout();
            this.panel50.SuspendLayout();
            this.p04.SuspendLayout();
            this.panel14.SuspendLayout();
            this.p18.SuspendLayout();
            this.panel53.SuspendLayout();
            this.p09.SuspendLayout();
            this.panel35.SuspendLayout();
            this.p15.SuspendLayout();
            this.panel56.SuspendLayout();
            this.p10.SuspendLayout();
            this.panel38.SuspendLayout();
            this.p13.SuspendLayout();
            this.panel59.SuspendLayout();
            this.p14.SuspendLayout();
            this.panel62.SuspendLayout();
            this.p07.SuspendLayout();
            this.panel20.SuspendLayout();
            this.p03.SuspendLayout();
            this.panel5.SuspendLayout();
            this.p05.SuspendLayout();
            this.panel23.SuspendLayout();
            this.p01.SuspendLayout();
            this.panel11.SuspendLayout();
            this.p06.SuspendLayout();
            this.panel26.SuspendLayout();
            this.p02.SuspendLayout();
            this.panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.freerooms_progress.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.panel1.Controls.Add(this.pictureBox12);
            this.panel1.Controls.Add(this.pictureBox11);
            this.panel1.Controls.Add(this.pictureBox10);
            this.panel1.Controls.Add(this.pictureBox9);
            this.panel1.Controls.Add(this.btnlogout);
            this.panel1.Controls.Add(this.btnbooking);
            this.panel1.Controls.Add(this.btncustomer);
            this.panel1.Controls.Add(this.btnuser);
            this.panel1.Controls.Add(this.btndashboard);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(186, 575);
            this.panel1.TabIndex = 0;
            // 
            // pictureBox12
            // 
            this.pictureBox12.BackgroundImage = global::Project06.Properties.Resources.png_clipart_computer_icons_calendar_date_time_rally_miscellaneous_blue_removebg_preview;
            this.pictureBox12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox12.Location = new System.Drawing.Point(29, 292);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(25, 25);
            this.pictureBox12.TabIndex = 58;
            this.pictureBox12.TabStop = false;
            // 
            // pictureBox11
            // 
            this.pictureBox11.BackgroundImage = global::Project06.Properties.Resources.profile03_removebg_preview;
            this.pictureBox11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox11.Location = new System.Drawing.Point(29, 251);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(25, 25);
            this.pictureBox11.TabIndex = 57;
            this.pictureBox11.TabStop = false;
            // 
            // pictureBox10
            // 
            this.pictureBox10.BackgroundImage = global::Project06.Properties.Resources._141_1418392_overnight_services_bed_icon_png_blue_removebg_preview;
            this.pictureBox10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox10.Location = new System.Drawing.Point(29, 210);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(25, 25);
            this.pictureBox10.TabIndex = 56;
            this.pictureBox10.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.BackgroundImage = global::Project06.Properties.Resources.images__1__removebg_preview1;
            this.pictureBox9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox9.Location = new System.Drawing.Point(29, 166);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(25, 25);
            this.pictureBox9.TabIndex = 55;
            this.pictureBox9.TabStop = false;
            // 
            // btnlogout
            // 
            this.btnlogout.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btnlogout.FlatAppearance.BorderSize = 0;
            this.btnlogout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnlogout.Font = new System.Drawing.Font("Nirmala UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnlogout.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.btnlogout.Location = new System.Drawing.Point(0, 533);
            this.btnlogout.Name = "btnlogout";
            this.btnlogout.Size = new System.Drawing.Size(186, 42);
            this.btnlogout.TabIndex = 5;
            this.btnlogout.Text = "Logout";
            this.btnlogout.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btnlogout.UseVisualStyleBackColor = true;
            this.btnlogout.Click += new System.EventHandler(this.btnlogout_Click);
            this.btnlogout.Leave += new System.EventHandler(this.btnlogout_Leave);
            // 
            // btnbooking
            // 
            this.btnbooking.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnbooking.FlatAppearance.BorderSize = 0;
            this.btnbooking.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnbooking.Font = new System.Drawing.Font("Nirmala UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnbooking.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.btnbooking.Location = new System.Drawing.Point(0, 286);
            this.btnbooking.Name = "btnbooking";
            this.btnbooking.Size = new System.Drawing.Size(186, 42);
            this.btnbooking.TabIndex = 4;
            this.btnbooking.Text = "Booking";
            this.btnbooking.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btnbooking.UseVisualStyleBackColor = true;
            this.btnbooking.Click += new System.EventHandler(this.btnbooking_Click);
            this.btnbooking.Leave += new System.EventHandler(this.btnbooking_Leave);
            // 
            // btncustomer
            // 
            this.btncustomer.Dock = System.Windows.Forms.DockStyle.Top;
            this.btncustomer.FlatAppearance.BorderSize = 0;
            this.btncustomer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btncustomer.Font = new System.Drawing.Font("Nirmala UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncustomer.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.btncustomer.Location = new System.Drawing.Point(0, 244);
            this.btncustomer.Name = "btncustomer";
            this.btncustomer.Size = new System.Drawing.Size(186, 42);
            this.btncustomer.TabIndex = 3;
            this.btncustomer.Text = "Customer";
            this.btncustomer.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btncustomer.UseVisualStyleBackColor = true;
            this.btncustomer.Click += new System.EventHandler(this.btncustomer_Click);
            this.btncustomer.Leave += new System.EventHandler(this.btncustomer_Leave);
            // 
            // btnuser
            // 
            this.btnuser.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnuser.FlatAppearance.BorderSize = 0;
            this.btnuser.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnuser.Font = new System.Drawing.Font("Nirmala UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnuser.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.btnuser.Location = new System.Drawing.Point(0, 202);
            this.btnuser.Name = "btnuser";
            this.btnuser.Size = new System.Drawing.Size(186, 42);
            this.btnuser.TabIndex = 2;
            this.btnuser.Text = "Users";
            this.btnuser.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btnuser.UseVisualStyleBackColor = true;
            this.btnuser.Click += new System.EventHandler(this.btnroom_Click);
            this.btnuser.Leave += new System.EventHandler(this.btnroom_Leave);
            // 
            // btndashboard
            // 
            this.btndashboard.Dock = System.Windows.Forms.DockStyle.Top;
            this.btndashboard.FlatAppearance.BorderSize = 0;
            this.btndashboard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btndashboard.Font = new System.Drawing.Font("Nirmala UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndashboard.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.btndashboard.Location = new System.Drawing.Point(0, 160);
            this.btndashboard.Name = "btndashboard";
            this.btndashboard.Size = new System.Drawing.Size(186, 42);
            this.btndashboard.TabIndex = 1;
            this.btndashboard.Text = "Dashboard";
            this.btndashboard.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btndashboard.UseMnemonic = false;
            this.btndashboard.UseVisualStyleBackColor = true;
            this.btndashboard.Click += new System.EventHandler(this.btndashboard_Click);
            this.btndashboard.Leave += new System.EventHandler(this.btndashboard_Leave);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(186, 160);
            this.panel2.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(158)))), ((int)(((byte)(161)))), ((int)(((byte)(178)))));
            this.label2.Location = new System.Drawing.Point(5, 141);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(179, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "Welcome AK Luxury Villa";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(66, 92);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "Profile";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Project06.Properties.Resources.profile_01_removebg_preview;
            this.pictureBox1.Location = new System.Drawing.Point(60, 22);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(63, 63);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // pnlnav
            // 
            this.pnlnav.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.pnlnav.Location = new System.Drawing.Point(0, 193);
            this.pnlnav.Name = "pnlnav";
            this.pnlnav.Size = new System.Drawing.Size(3, 100);
            this.pnlnav.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 21F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(158)))), ((int)(((byte)(161)))), ((int)(((byte)(176)))));
            this.label3.Location = new System.Drawing.Point(240, 18);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(163, 32);
            this.label3.TabIndex = 2;
            this.label3.Text = "Dashboard";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(79)))), ((int)(((byte)(99)))));
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Font = new System.Drawing.Font("Myanmar Text", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            this.textBox1.Location = new System.Drawing.Point(598, 22);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(292, 20);
            this.textBox1.TabIndex = 3;
            this.textBox1.Text = "Search";
            // 
            // button1
            // 
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(912, 15);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(25, 25);
            this.button1.TabIndex = 4;
            this.button1.Text = "X";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.panel3.Controls.Add(this.p24);
            this.panel3.Controls.Add(this.p20);
            this.panel3.Controls.Add(this.p23);
            this.panel3.Controls.Add(this.p12);
            this.panel3.Controls.Add(this.p21);
            this.panel3.Controls.Add(this.p22);
            this.panel3.Controls.Add(this.p16);
            this.panel3.Controls.Add(this.p08);
            this.panel3.Controls.Add(this.p19);
            this.panel3.Controls.Add(this.p11);
            this.panel3.Controls.Add(this.p17);
            this.panel3.Controls.Add(this.p04);
            this.panel3.Controls.Add(this.p18);
            this.panel3.Controls.Add(this.p09);
            this.panel3.Controls.Add(this.p15);
            this.panel3.Controls.Add(this.p10);
            this.panel3.Controls.Add(this.p13);
            this.panel3.Controls.Add(this.p14);
            this.panel3.Controls.Add(this.p07);
            this.panel3.Controls.Add(this.p03);
            this.panel3.Controls.Add(this.p05);
            this.panel3.Controls.Add(this.p01);
            this.panel3.Controls.Add(this.p06);
            this.panel3.Controls.Add(this.p02);
            this.panel3.Location = new System.Drawing.Point(206, 210);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(464, 335);
            this.panel3.TabIndex = 5;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // p24
            // 
            this.p24.BackColor = System.Drawing.Color.SlateGray;
            this.p24.Controls.Add(this.room24);
            this.p24.Controls.Add(this.panel65);
            this.p24.Location = new System.Drawing.Point(345, 273);
            this.p24.Name = "p24";
            this.p24.Size = new System.Drawing.Size(115, 54);
            this.p24.TabIndex = 35;
            this.p24.Click += new System.EventHandler(this.p24_Click);
            this.p24.Paint += new System.Windows.Forms.PaintEventHandler(this.p24_Paint);
            // 
            // room24
            // 
            this.room24.AutoSize = true;
            this.room24.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.room24.ForeColor = System.Drawing.Color.Snow;
            this.room24.Location = new System.Drawing.Point(12, 9);
            this.room24.Name = "room24";
            this.room24.Size = new System.Drawing.Size(62, 17);
            this.room24.TabIndex = 42;
            this.room24.Text = "Room 24";
            // 
            // panel65
            // 
            this.panel65.BackColor = System.Drawing.Color.White;
            this.panel65.Controls.Add(this.panel66);
            this.panel65.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel65.Location = new System.Drawing.Point(0, 0);
            this.panel65.Name = "panel65";
            this.panel65.Size = new System.Drawing.Size(5, 54);
            this.panel65.TabIndex = 1;
            // 
            // panel66
            // 
            this.panel66.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.panel66.Location = new System.Drawing.Point(0, 0);
            this.panel66.Name = "panel66";
            this.panel66.Size = new System.Drawing.Size(5, 54);
            this.panel66.TabIndex = 2;
            // 
            // p20
            // 
            this.p20.BackColor = System.Drawing.Color.SlateGray;
            this.p20.Controls.Add(this.room20);
            this.p20.Controls.Add(this.panel41);
            this.p20.Location = new System.Drawing.Point(345, 219);
            this.p20.Name = "p20";
            this.p20.Size = new System.Drawing.Size(115, 54);
            this.p20.TabIndex = 31;
            this.p20.Click += new System.EventHandler(this.p20_Click);
            this.p20.Paint += new System.Windows.Forms.PaintEventHandler(this.p20_Paint);
            // 
            // room20
            // 
            this.room20.AutoSize = true;
            this.room20.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.room20.ForeColor = System.Drawing.Color.Snow;
            this.room20.Location = new System.Drawing.Point(12, 9);
            this.room20.Name = "room20";
            this.room20.Size = new System.Drawing.Size(62, 17);
            this.room20.TabIndex = 41;
            this.room20.Text = "Room 20";
            // 
            // panel41
            // 
            this.panel41.BackColor = System.Drawing.Color.White;
            this.panel41.Controls.Add(this.panel42);
            this.panel41.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel41.Location = new System.Drawing.Point(0, 0);
            this.panel41.Name = "panel41";
            this.panel41.Size = new System.Drawing.Size(5, 54);
            this.panel41.TabIndex = 1;
            // 
            // panel42
            // 
            this.panel42.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.panel42.Location = new System.Drawing.Point(0, 0);
            this.panel42.Name = "panel42";
            this.panel42.Size = new System.Drawing.Size(5, 54);
            this.panel42.TabIndex = 2;
            // 
            // p23
            // 
            this.p23.BackColor = System.Drawing.Color.SlateGray;
            this.p23.Controls.Add(this.room23);
            this.p23.Controls.Add(this.panel68);
            this.p23.Location = new System.Drawing.Point(231, 273);
            this.p23.Name = "p23";
            this.p23.Size = new System.Drawing.Size(115, 54);
            this.p23.TabIndex = 33;
            this.p23.Click += new System.EventHandler(this.p23_Click);
            this.p23.Paint += new System.Windows.Forms.PaintEventHandler(this.p23_Paint);
            // 
            // room23
            // 
            this.room23.AutoSize = true;
            this.room23.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.room23.ForeColor = System.Drawing.Color.Snow;
            this.room23.Location = new System.Drawing.Point(12, 9);
            this.room23.Name = "room23";
            this.room23.Size = new System.Drawing.Size(62, 17);
            this.room23.TabIndex = 36;
            this.room23.Text = "Room 23";
            // 
            // panel68
            // 
            this.panel68.BackColor = System.Drawing.Color.White;
            this.panel68.Controls.Add(this.panel69);
            this.panel68.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel68.Location = new System.Drawing.Point(0, 0);
            this.panel68.Name = "panel68";
            this.panel68.Size = new System.Drawing.Size(5, 54);
            this.panel68.TabIndex = 1;
            // 
            // panel69
            // 
            this.panel69.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.panel69.Location = new System.Drawing.Point(0, 0);
            this.panel69.Name = "panel69";
            this.panel69.Size = new System.Drawing.Size(5, 54);
            this.panel69.TabIndex = 2;
            // 
            // p12
            // 
            this.p12.BackColor = System.Drawing.Color.SlateGray;
            this.p12.Controls.Add(this.room12);
            this.p12.Controls.Add(this.panel29);
            this.p12.Location = new System.Drawing.Point(345, 111);
            this.p12.Name = "p12";
            this.p12.Size = new System.Drawing.Size(115, 54);
            this.p12.TabIndex = 24;
            this.p12.Click += new System.EventHandler(this.p12_Click);
            this.p12.Paint += new System.Windows.Forms.PaintEventHandler(this.p12_Paint);
            // 
            // room12
            // 
            this.room12.AutoSize = true;
            this.room12.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.room12.ForeColor = System.Drawing.Color.Snow;
            this.room12.Location = new System.Drawing.Point(12, 9);
            this.room12.Name = "room12";
            this.room12.Size = new System.Drawing.Size(62, 17);
            this.room12.TabIndex = 39;
            this.room12.Text = "Room 12";
            // 
            // panel29
            // 
            this.panel29.BackColor = System.Drawing.Color.White;
            this.panel29.Controls.Add(this.panel30);
            this.panel29.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel29.Location = new System.Drawing.Point(0, 0);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(5, 54);
            this.panel29.TabIndex = 1;
            // 
            // panel30
            // 
            this.panel30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.panel30.Location = new System.Drawing.Point(0, 0);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(5, 54);
            this.panel30.TabIndex = 2;
            // 
            // p21
            // 
            this.p21.BackColor = System.Drawing.Color.SlateGray;
            this.p21.Controls.Add(this.room21);
            this.p21.Controls.Add(this.panel71);
            this.p21.Location = new System.Drawing.Point(3, 273);
            this.p21.Name = "p21";
            this.p21.Size = new System.Drawing.Size(115, 54);
            this.p21.TabIndex = 34;
            this.p21.Click += new System.EventHandler(this.p21_Click);
            this.p21.Paint += new System.Windows.Forms.PaintEventHandler(this.p21_Paint);
            // 
            // room21
            // 
            this.room21.AutoSize = true;
            this.room21.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.room21.ForeColor = System.Drawing.Color.Snow;
            this.room21.Location = new System.Drawing.Point(12, 9);
            this.room21.Name = "room21";
            this.room21.Size = new System.Drawing.Size(62, 17);
            this.room21.TabIndex = 29;
            this.room21.Text = "Room 21";
            // 
            // panel71
            // 
            this.panel71.BackColor = System.Drawing.Color.White;
            this.panel71.Controls.Add(this.panel72);
            this.panel71.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel71.Location = new System.Drawing.Point(0, 0);
            this.panel71.Name = "panel71";
            this.panel71.Size = new System.Drawing.Size(5, 54);
            this.panel71.TabIndex = 1;
            // 
            // panel72
            // 
            this.panel72.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.panel72.Location = new System.Drawing.Point(0, 0);
            this.panel72.Name = "panel72";
            this.panel72.Size = new System.Drawing.Size(5, 54);
            this.panel72.TabIndex = 2;
            // 
            // p22
            // 
            this.p22.BackColor = System.Drawing.Color.SlateGray;
            this.p22.Controls.Add(this.room22);
            this.p22.Controls.Add(this.panel74);
            this.p22.Location = new System.Drawing.Point(117, 273);
            this.p22.Name = "p22";
            this.p22.Size = new System.Drawing.Size(115, 54);
            this.p22.TabIndex = 32;
            this.p22.Click += new System.EventHandler(this.p22_Click);
            this.p22.Paint += new System.Windows.Forms.PaintEventHandler(this.p22_Paint);
            // 
            // room22
            // 
            this.room22.AutoSize = true;
            this.room22.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.room22.ForeColor = System.Drawing.Color.Snow;
            this.room22.Location = new System.Drawing.Point(12, 9);
            this.room22.Name = "room22";
            this.room22.Size = new System.Drawing.Size(62, 17);
            this.room22.TabIndex = 30;
            this.room22.Text = "Room 22";
            // 
            // panel74
            // 
            this.panel74.BackColor = System.Drawing.Color.White;
            this.panel74.Controls.Add(this.panel75);
            this.panel74.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel74.Location = new System.Drawing.Point(0, 0);
            this.panel74.Name = "panel74";
            this.panel74.Size = new System.Drawing.Size(5, 54);
            this.panel74.TabIndex = 1;
            // 
            // panel75
            // 
            this.panel75.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.panel75.Location = new System.Drawing.Point(0, 0);
            this.panel75.Name = "panel75";
            this.panel75.Size = new System.Drawing.Size(5, 54);
            this.panel75.TabIndex = 2;
            // 
            // p16
            // 
            this.p16.BackColor = System.Drawing.Color.SlateGray;
            this.p16.Controls.Add(this.room16);
            this.p16.Controls.Add(this.panel44);
            this.p16.Location = new System.Drawing.Point(345, 165);
            this.p16.Name = "p16";
            this.p16.Size = new System.Drawing.Size(115, 54);
            this.p16.TabIndex = 32;
            this.p16.Click += new System.EventHandler(this.p16_Click);
            this.p16.Paint += new System.Windows.Forms.PaintEventHandler(this.p16_Paint);
            // 
            // room16
            // 
            this.room16.AutoSize = true;
            this.room16.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.room16.ForeColor = System.Drawing.Color.Snow;
            this.room16.Location = new System.Drawing.Point(12, 9);
            this.room16.Name = "room16";
            this.room16.Size = new System.Drawing.Size(62, 17);
            this.room16.TabIndex = 40;
            this.room16.Text = "Room 16";
            // 
            // panel44
            // 
            this.panel44.BackColor = System.Drawing.Color.White;
            this.panel44.Controls.Add(this.panel45);
            this.panel44.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel44.Location = new System.Drawing.Point(0, 0);
            this.panel44.Name = "panel44";
            this.panel44.Size = new System.Drawing.Size(5, 54);
            this.panel44.TabIndex = 1;
            // 
            // panel45
            // 
            this.panel45.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.panel45.Location = new System.Drawing.Point(0, 0);
            this.panel45.Name = "panel45";
            this.panel45.Size = new System.Drawing.Size(5, 54);
            this.panel45.TabIndex = 2;
            // 
            // p08
            // 
            this.p08.BackColor = System.Drawing.Color.SlateGray;
            this.p08.Controls.Add(this.room8);
            this.p08.Controls.Add(this.panel17);
            this.p08.Location = new System.Drawing.Point(345, 57);
            this.p08.Name = "p08";
            this.p08.Size = new System.Drawing.Size(115, 54);
            this.p08.TabIndex = 24;
            this.p08.Click += new System.EventHandler(this.p08_Click);
            this.p08.Paint += new System.Windows.Forms.PaintEventHandler(this.p08_Paint);
            // 
            // room8
            // 
            this.room8.AutoSize = true;
            this.room8.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.room8.ForeColor = System.Drawing.Color.Snow;
            this.room8.Location = new System.Drawing.Point(12, 9);
            this.room8.Name = "room8";
            this.room8.Size = new System.Drawing.Size(62, 17);
            this.room8.TabIndex = 38;
            this.room8.Text = "Room 08";
            // 
            // panel17
            // 
            this.panel17.BackColor = System.Drawing.Color.White;
            this.panel17.Controls.Add(this.panel18);
            this.panel17.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel17.Location = new System.Drawing.Point(0, 0);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(5, 54);
            this.panel17.TabIndex = 1;
            // 
            // panel18
            // 
            this.panel18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.panel18.Location = new System.Drawing.Point(0, 0);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(5, 54);
            this.panel18.TabIndex = 2;
            // 
            // p19
            // 
            this.p19.BackColor = System.Drawing.Color.SlateGray;
            this.p19.Controls.Add(this.room19);
            this.p19.Controls.Add(this.panel47);
            this.p19.Location = new System.Drawing.Point(231, 219);
            this.p19.Name = "p19";
            this.p19.Size = new System.Drawing.Size(115, 54);
            this.p19.TabIndex = 27;
            this.p19.Click += new System.EventHandler(this.p19_Click);
            this.p19.Paint += new System.Windows.Forms.PaintEventHandler(this.p19_Paint);
            // 
            // room19
            // 
            this.room19.AutoSize = true;
            this.room19.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.room19.ForeColor = System.Drawing.Color.Snow;
            this.room19.Location = new System.Drawing.Point(12, 9);
            this.room19.Name = "room19";
            this.room19.Size = new System.Drawing.Size(62, 17);
            this.room19.TabIndex = 35;
            this.room19.Text = "Room 19";
            // 
            // panel47
            // 
            this.panel47.BackColor = System.Drawing.Color.White;
            this.panel47.Controls.Add(this.panel48);
            this.panel47.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel47.Location = new System.Drawing.Point(0, 0);
            this.panel47.Name = "panel47";
            this.panel47.Size = new System.Drawing.Size(5, 54);
            this.panel47.TabIndex = 1;
            // 
            // panel48
            // 
            this.panel48.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.panel48.Location = new System.Drawing.Point(0, 0);
            this.panel48.Name = "panel48";
            this.panel48.Size = new System.Drawing.Size(5, 54);
            this.panel48.TabIndex = 2;
            // 
            // p11
            // 
            this.p11.BackColor = System.Drawing.Color.SlateGray;
            this.p11.Controls.Add(this.room11);
            this.p11.Controls.Add(this.panel32);
            this.p11.Location = new System.Drawing.Point(231, 111);
            this.p11.Name = "p11";
            this.p11.Size = new System.Drawing.Size(115, 54);
            this.p11.TabIndex = 22;
            this.p11.Click += new System.EventHandler(this.p11_Click);
            this.p11.Paint += new System.Windows.Forms.PaintEventHandler(this.p11_Paint);
            // 
            // room11
            // 
            this.room11.AutoSize = true;
            this.room11.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.room11.ForeColor = System.Drawing.Color.Snow;
            this.room11.Location = new System.Drawing.Point(12, 9);
            this.room11.Name = "room11";
            this.room11.Size = new System.Drawing.Size(62, 17);
            this.room11.TabIndex = 33;
            this.room11.Text = "Room 11";
            // 
            // panel32
            // 
            this.panel32.BackColor = System.Drawing.Color.White;
            this.panel32.Controls.Add(this.panel33);
            this.panel32.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel32.Location = new System.Drawing.Point(0, 0);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(5, 54);
            this.panel32.TabIndex = 1;
            // 
            // panel33
            // 
            this.panel33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.panel33.Location = new System.Drawing.Point(0, 0);
            this.panel33.Name = "panel33";
            this.panel33.Size = new System.Drawing.Size(5, 54);
            this.panel33.TabIndex = 2;
            // 
            // p17
            // 
            this.p17.BackColor = System.Drawing.Color.SlateGray;
            this.p17.Controls.Add(this.room17);
            this.p17.Controls.Add(this.panel50);
            this.p17.Location = new System.Drawing.Point(3, 219);
            this.p17.Name = "p17";
            this.p17.Size = new System.Drawing.Size(115, 54);
            this.p17.TabIndex = 29;
            this.p17.Click += new System.EventHandler(this.p17_Click);
            this.p17.Paint += new System.Windows.Forms.PaintEventHandler(this.p17_Paint);
            // 
            // room17
            // 
            this.room17.AutoSize = true;
            this.room17.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.room17.ForeColor = System.Drawing.Color.Snow;
            this.room17.Location = new System.Drawing.Point(12, 9);
            this.room17.Name = "room17";
            this.room17.Size = new System.Drawing.Size(62, 17);
            this.room17.TabIndex = 28;
            this.room17.Text = "Room 17";
            // 
            // panel50
            // 
            this.panel50.BackColor = System.Drawing.Color.White;
            this.panel50.Controls.Add(this.panel51);
            this.panel50.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel50.Location = new System.Drawing.Point(0, 0);
            this.panel50.Name = "panel50";
            this.panel50.Size = new System.Drawing.Size(5, 54);
            this.panel50.TabIndex = 1;
            // 
            // panel51
            // 
            this.panel51.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.panel51.Location = new System.Drawing.Point(0, 0);
            this.panel51.Name = "panel51";
            this.panel51.Size = new System.Drawing.Size(5, 54);
            this.panel51.TabIndex = 2;
            // 
            // p04
            // 
            this.p04.BackColor = System.Drawing.Color.SlateGray;
            this.p04.Controls.Add(this.room4);
            this.p04.Controls.Add(this.panel14);
            this.p04.Location = new System.Drawing.Point(345, 3);
            this.p04.Name = "p04";
            this.p04.Size = new System.Drawing.Size(115, 54);
            this.p04.TabIndex = 4;
            this.p04.Click += new System.EventHandler(this.p04_Click);
            // 
            // room4
            // 
            this.room4.AutoSize = true;
            this.room4.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.room4.ForeColor = System.Drawing.Color.Snow;
            this.room4.Location = new System.Drawing.Point(12, 9);
            this.room4.Name = "room4";
            this.room4.Size = new System.Drawing.Size(62, 17);
            this.room4.TabIndex = 37;
            this.room4.Text = "Room 04";
            this.room4.Click += new System.EventHandler(this.room4_Click);
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.White;
            this.panel14.Controls.Add(this.panel15);
            this.panel14.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel14.Location = new System.Drawing.Point(0, 0);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(5, 54);
            this.panel14.TabIndex = 1;
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.panel15.Location = new System.Drawing.Point(0, 0);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(5, 54);
            this.panel15.TabIndex = 2;
            // 
            // p18
            // 
            this.p18.BackColor = System.Drawing.Color.SlateGray;
            this.p18.Controls.Add(this.room18);
            this.p18.Controls.Add(this.panel53);
            this.p18.Location = new System.Drawing.Point(117, 219);
            this.p18.Name = "p18";
            this.p18.Size = new System.Drawing.Size(115, 54);
            this.p18.TabIndex = 25;
            this.p18.Click += new System.EventHandler(this.p18_Click);
            this.p18.Paint += new System.Windows.Forms.PaintEventHandler(this.p18_Paint);
            // 
            // room18
            // 
            this.room18.AutoSize = true;
            this.room18.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.room18.ForeColor = System.Drawing.Color.Snow;
            this.room18.Location = new System.Drawing.Point(12, 9);
            this.room18.Name = "room18";
            this.room18.Size = new System.Drawing.Size(62, 17);
            this.room18.TabIndex = 29;
            this.room18.Text = "Room 18";
            // 
            // panel53
            // 
            this.panel53.BackColor = System.Drawing.Color.White;
            this.panel53.Controls.Add(this.panel54);
            this.panel53.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel53.Location = new System.Drawing.Point(0, 0);
            this.panel53.Name = "panel53";
            this.panel53.Size = new System.Drawing.Size(5, 54);
            this.panel53.TabIndex = 1;
            // 
            // panel54
            // 
            this.panel54.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.panel54.Location = new System.Drawing.Point(0, 0);
            this.panel54.Name = "panel54";
            this.panel54.Size = new System.Drawing.Size(5, 54);
            this.panel54.TabIndex = 2;
            // 
            // p09
            // 
            this.p09.BackColor = System.Drawing.Color.SlateGray;
            this.p09.Controls.Add(this.room9);
            this.p09.Controls.Add(this.panel35);
            this.p09.Location = new System.Drawing.Point(3, 111);
            this.p09.Name = "p09";
            this.p09.Size = new System.Drawing.Size(115, 54);
            this.p09.TabIndex = 23;
            this.p09.Click += new System.EventHandler(this.p09_Click);
            this.p09.Paint += new System.Windows.Forms.PaintEventHandler(this.p09_Paint);
            // 
            // room9
            // 
            this.room9.AutoSize = true;
            this.room9.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.room9.ForeColor = System.Drawing.Color.Snow;
            this.room9.Location = new System.Drawing.Point(12, 9);
            this.room9.Name = "room9";
            this.room9.Size = new System.Drawing.Size(62, 17);
            this.room9.TabIndex = 26;
            this.room9.Text = "Room 09";
            // 
            // panel35
            // 
            this.panel35.BackColor = System.Drawing.Color.White;
            this.panel35.Controls.Add(this.panel36);
            this.panel35.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel35.Location = new System.Drawing.Point(0, 0);
            this.panel35.Name = "panel35";
            this.panel35.Size = new System.Drawing.Size(5, 54);
            this.panel35.TabIndex = 1;
            // 
            // panel36
            // 
            this.panel36.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.panel36.Location = new System.Drawing.Point(0, 0);
            this.panel36.Name = "panel36";
            this.panel36.Size = new System.Drawing.Size(5, 54);
            this.panel36.TabIndex = 2;
            // 
            // p15
            // 
            this.p15.BackColor = System.Drawing.Color.SlateGray;
            this.p15.Controls.Add(this.room15);
            this.p15.Controls.Add(this.panel56);
            this.p15.Location = new System.Drawing.Point(231, 165);
            this.p15.Name = "p15";
            this.p15.Size = new System.Drawing.Size(115, 54);
            this.p15.TabIndex = 28;
            this.p15.Click += new System.EventHandler(this.p15_Click);
            this.p15.Paint += new System.Windows.Forms.PaintEventHandler(this.p15_Paint);
            // 
            // room15
            // 
            this.room15.AutoSize = true;
            this.room15.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.room15.ForeColor = System.Drawing.Color.Snow;
            this.room15.Location = new System.Drawing.Point(12, 9);
            this.room15.Name = "room15";
            this.room15.Size = new System.Drawing.Size(62, 17);
            this.room15.TabIndex = 34;
            this.room15.Text = "Room 15";
            // 
            // panel56
            // 
            this.panel56.BackColor = System.Drawing.Color.White;
            this.panel56.Controls.Add(this.panel57);
            this.panel56.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel56.Location = new System.Drawing.Point(0, 0);
            this.panel56.Name = "panel56";
            this.panel56.Size = new System.Drawing.Size(5, 54);
            this.panel56.TabIndex = 1;
            // 
            // panel57
            // 
            this.panel57.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.panel57.Location = new System.Drawing.Point(0, 0);
            this.panel57.Name = "panel57";
            this.panel57.Size = new System.Drawing.Size(5, 54);
            this.panel57.TabIndex = 2;
            // 
            // p10
            // 
            this.p10.BackColor = System.Drawing.Color.SlateGray;
            this.p10.Controls.Add(this.room10);
            this.p10.Controls.Add(this.panel38);
            this.p10.Location = new System.Drawing.Point(117, 111);
            this.p10.Name = "p10";
            this.p10.Size = new System.Drawing.Size(115, 54);
            this.p10.TabIndex = 21;
            this.p10.Click += new System.EventHandler(this.p10_Click);
            this.p10.Paint += new System.Windows.Forms.PaintEventHandler(this.p10_Paint);
            // 
            // room10
            // 
            this.room10.AutoSize = true;
            this.room10.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.room10.ForeColor = System.Drawing.Color.Snow;
            this.room10.Location = new System.Drawing.Point(12, 9);
            this.room10.Name = "room10";
            this.room10.Size = new System.Drawing.Size(62, 17);
            this.room10.TabIndex = 27;
            this.room10.Text = "Room 10";
            // 
            // panel38
            // 
            this.panel38.BackColor = System.Drawing.Color.White;
            this.panel38.Controls.Add(this.panel39);
            this.panel38.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel38.Location = new System.Drawing.Point(0, 0);
            this.panel38.Name = "panel38";
            this.panel38.Size = new System.Drawing.Size(5, 54);
            this.panel38.TabIndex = 1;
            // 
            // panel39
            // 
            this.panel39.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.panel39.Location = new System.Drawing.Point(0, 0);
            this.panel39.Name = "panel39";
            this.panel39.Size = new System.Drawing.Size(5, 54);
            this.panel39.TabIndex = 2;
            // 
            // p13
            // 
            this.p13.BackColor = System.Drawing.Color.SlateGray;
            this.p13.Controls.Add(this.room13);
            this.p13.Controls.Add(this.panel59);
            this.p13.Location = new System.Drawing.Point(3, 165);
            this.p13.Name = "p13";
            this.p13.Size = new System.Drawing.Size(115, 54);
            this.p13.TabIndex = 30;
            this.p13.Click += new System.EventHandler(this.p13_Click);
            this.p13.Paint += new System.Windows.Forms.PaintEventHandler(this.p13_Paint);
            // 
            // room13
            // 
            this.room13.AutoSize = true;
            this.room13.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.room13.ForeColor = System.Drawing.Color.Snow;
            this.room13.Location = new System.Drawing.Point(12, 9);
            this.room13.Name = "room13";
            this.room13.Size = new System.Drawing.Size(62, 17);
            this.room13.TabIndex = 27;
            this.room13.Text = "Room 13";
            // 
            // panel59
            // 
            this.panel59.BackColor = System.Drawing.Color.White;
            this.panel59.Controls.Add(this.panel60);
            this.panel59.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel59.Location = new System.Drawing.Point(0, 0);
            this.panel59.Name = "panel59";
            this.panel59.Size = new System.Drawing.Size(5, 54);
            this.panel59.TabIndex = 1;
            // 
            // panel60
            // 
            this.panel60.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.panel60.Location = new System.Drawing.Point(0, 0);
            this.panel60.Name = "panel60";
            this.panel60.Size = new System.Drawing.Size(5, 54);
            this.panel60.TabIndex = 2;
            // 
            // p14
            // 
            this.p14.BackColor = System.Drawing.Color.SlateGray;
            this.p14.Controls.Add(this.room14);
            this.p14.Controls.Add(this.panel62);
            this.p14.Location = new System.Drawing.Point(117, 165);
            this.p14.Name = "p14";
            this.p14.Size = new System.Drawing.Size(115, 54);
            this.p14.TabIndex = 26;
            this.p14.Click += new System.EventHandler(this.p14_Click);
            this.p14.Paint += new System.Windows.Forms.PaintEventHandler(this.p14_Paint);
            // 
            // room14
            // 
            this.room14.AutoSize = true;
            this.room14.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.room14.ForeColor = System.Drawing.Color.Snow;
            this.room14.Location = new System.Drawing.Point(12, 9);
            this.room14.Name = "room14";
            this.room14.Size = new System.Drawing.Size(62, 17);
            this.room14.TabIndex = 28;
            this.room14.Text = "Room 14";
            // 
            // panel62
            // 
            this.panel62.BackColor = System.Drawing.Color.White;
            this.panel62.Controls.Add(this.panel63);
            this.panel62.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel62.Location = new System.Drawing.Point(0, 0);
            this.panel62.Name = "panel62";
            this.panel62.Size = new System.Drawing.Size(5, 54);
            this.panel62.TabIndex = 1;
            // 
            // panel63
            // 
            this.panel63.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.panel63.Location = new System.Drawing.Point(0, 0);
            this.panel63.Name = "panel63";
            this.panel63.Size = new System.Drawing.Size(5, 54);
            this.panel63.TabIndex = 2;
            // 
            // p07
            // 
            this.p07.BackColor = System.Drawing.Color.SlateGray;
            this.p07.Controls.Add(this.room7);
            this.p07.Controls.Add(this.panel20);
            this.p07.Location = new System.Drawing.Point(231, 57);
            this.p07.Name = "p07";
            this.p07.Size = new System.Drawing.Size(115, 54);
            this.p07.TabIndex = 22;
            this.p07.Click += new System.EventHandler(this.p07_Click);
            this.p07.Paint += new System.Windows.Forms.PaintEventHandler(this.p07_Paint);
            // 
            // room7
            // 
            this.room7.AutoSize = true;
            this.room7.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.room7.ForeColor = System.Drawing.Color.Snow;
            this.room7.Location = new System.Drawing.Point(12, 9);
            this.room7.Name = "room7";
            this.room7.Size = new System.Drawing.Size(62, 17);
            this.room7.TabIndex = 32;
            this.room7.Text = "Room 07";
            // 
            // panel20
            // 
            this.panel20.BackColor = System.Drawing.Color.White;
            this.panel20.Controls.Add(this.panel21);
            this.panel20.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel20.Location = new System.Drawing.Point(0, 0);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(5, 54);
            this.panel20.TabIndex = 1;
            // 
            // panel21
            // 
            this.panel21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.panel21.Location = new System.Drawing.Point(0, 0);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(5, 54);
            this.panel21.TabIndex = 2;
            // 
            // p03
            // 
            this.p03.BackColor = System.Drawing.Color.SlateGray;
            this.p03.Controls.Add(this.room3);
            this.p03.Controls.Add(this.panel5);
            this.p03.Location = new System.Drawing.Point(231, 3);
            this.p03.Name = "p03";
            this.p03.Size = new System.Drawing.Size(115, 54);
            this.p03.TabIndex = 3;
            this.p03.Click += new System.EventHandler(this.p03_Click);
            this.p03.Paint += new System.Windows.Forms.PaintEventHandler(this.p03_Paint);
            // 
            // room3
            // 
            this.room3.AutoSize = true;
            this.room3.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.room3.ForeColor = System.Drawing.Color.Snow;
            this.room3.Location = new System.Drawing.Point(12, 9);
            this.room3.Name = "room3";
            this.room3.Size = new System.Drawing.Size(62, 17);
            this.room3.TabIndex = 31;
            this.room3.Text = "Room 03";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.White;
            this.panel5.Controls.Add(this.panel6);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(5, 54);
            this.panel5.TabIndex = 1;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.panel6.Location = new System.Drawing.Point(0, 0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(5, 54);
            this.panel6.TabIndex = 2;
            // 
            // p05
            // 
            this.p05.BackColor = System.Drawing.Color.SlateGray;
            this.p05.Controls.Add(this.room5);
            this.p05.Controls.Add(this.panel23);
            this.p05.Location = new System.Drawing.Point(3, 57);
            this.p05.Name = "p05";
            this.p05.Size = new System.Drawing.Size(115, 54);
            this.p05.TabIndex = 23;
            this.p05.Click += new System.EventHandler(this.p05_Click);
            this.p05.Paint += new System.Windows.Forms.PaintEventHandler(this.p05_Paint);
            // 
            // room5
            // 
            this.room5.AutoSize = true;
            this.room5.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.room5.ForeColor = System.Drawing.Color.Snow;
            this.room5.Location = new System.Drawing.Point(12, 9);
            this.room5.Name = "room5";
            this.room5.Size = new System.Drawing.Size(62, 17);
            this.room5.TabIndex = 25;
            this.room5.Text = "Room 05";
            // 
            // panel23
            // 
            this.panel23.BackColor = System.Drawing.Color.White;
            this.panel23.Controls.Add(this.panel24);
            this.panel23.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel23.Location = new System.Drawing.Point(0, 0);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(5, 54);
            this.panel23.TabIndex = 1;
            // 
            // panel24
            // 
            this.panel24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.panel24.Location = new System.Drawing.Point(0, 0);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(5, 54);
            this.panel24.TabIndex = 2;
            // 
            // p01
            // 
            this.p01.BackColor = System.Drawing.Color.SlateGray;
            this.p01.Controls.Add(this.room1);
            this.p01.Controls.Add(this.panel11);
            this.p01.Location = new System.Drawing.Point(3, 3);
            this.p01.Name = "p01";
            this.p01.Size = new System.Drawing.Size(115, 54);
            this.p01.TabIndex = 3;
            this.p01.Click += new System.EventHandler(this.p01_Click);
            this.p01.Paint += new System.Windows.Forms.PaintEventHandler(this.p01_Paint);
            // 
            // room1
            // 
            this.room1.AutoSize = true;
            this.room1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.room1.ForeColor = System.Drawing.Color.Snow;
            this.room1.Location = new System.Drawing.Point(12, 9);
            this.room1.Name = "room1";
            this.room1.Size = new System.Drawing.Size(62, 17);
            this.room1.TabIndex = 24;
            this.room1.Text = "Room 01";
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.White;
            this.panel11.Controls.Add(this.panel12);
            this.panel11.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel11.Location = new System.Drawing.Point(0, 0);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(5, 54);
            this.panel11.TabIndex = 1;
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.panel12.Location = new System.Drawing.Point(0, 0);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(5, 54);
            this.panel12.TabIndex = 2;
            // 
            // p06
            // 
            this.p06.BackColor = System.Drawing.Color.SlateGray;
            this.p06.Controls.Add(this.room6);
            this.p06.Controls.Add(this.panel26);
            this.p06.Location = new System.Drawing.Point(117, 57);
            this.p06.Name = "p06";
            this.p06.Size = new System.Drawing.Size(115, 54);
            this.p06.TabIndex = 21;
            this.p06.Click += new System.EventHandler(this.p06_Click);
            this.p06.Paint += new System.Windows.Forms.PaintEventHandler(this.p06_Paint);
            // 
            // room6
            // 
            this.room6.AutoSize = true;
            this.room6.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.room6.ForeColor = System.Drawing.Color.Snow;
            this.room6.Location = new System.Drawing.Point(12, 9);
            this.room6.Name = "room6";
            this.room6.Size = new System.Drawing.Size(62, 17);
            this.room6.TabIndex = 26;
            this.room6.Text = "Room 06";
            // 
            // panel26
            // 
            this.panel26.BackColor = System.Drawing.Color.White;
            this.panel26.Controls.Add(this.panel27);
            this.panel26.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel26.Location = new System.Drawing.Point(0, 0);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(5, 54);
            this.panel26.TabIndex = 1;
            // 
            // panel27
            // 
            this.panel27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.panel27.Location = new System.Drawing.Point(0, 0);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(5, 54);
            this.panel27.TabIndex = 2;
            // 
            // p02
            // 
            this.p02.BackColor = System.Drawing.Color.SlateGray;
            this.p02.Controls.Add(this.room2);
            this.p02.Controls.Add(this.panel8);
            this.p02.Location = new System.Drawing.Point(117, 3);
            this.p02.Name = "p02";
            this.p02.Size = new System.Drawing.Size(115, 54);
            this.p02.TabIndex = 2;
            this.p02.Click += new System.EventHandler(this.p02_Click);
            this.p02.Paint += new System.Windows.Forms.PaintEventHandler(this.p02_Paint);
            // 
            // room2
            // 
            this.room2.AutoSize = true;
            this.room2.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.room2.ForeColor = System.Drawing.Color.Snow;
            this.room2.Location = new System.Drawing.Point(12, 9);
            this.room2.Name = "room2";
            this.room2.Size = new System.Drawing.Size(62, 17);
            this.room2.TabIndex = 25;
            this.room2.Text = "Room 02";
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.White;
            this.panel8.Controls.Add(this.panel9);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel8.Location = new System.Drawing.Point(0, 0);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(5, 54);
            this.panel8.TabIndex = 1;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.panel9.Location = new System.Drawing.Point(0, 0);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(5, 54);
            this.panel9.TabIndex = 2;
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 35;
            this.bunifuElipse1.TargetControl = this;
            // 
            // Ava_lb
            // 
            this.Ava_lb.AutoSize = true;
            this.Ava_lb.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Ava_lb.ForeColor = System.Drawing.Color.White;
            this.Ava_lb.Location = new System.Drawing.Point(767, 269);
            this.Ava_lb.Name = "Ava_lb";
            this.Ava_lb.Size = new System.Drawing.Size(57, 15);
            this.Ava_lb.TabIndex = 9;
            this.Ava_lb.Text = "Available";
            // 
            // Book_lb
            // 
            this.Book_lb.AutoSize = true;
            this.Book_lb.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Book_lb.ForeColor = System.Drawing.Color.White;
            this.Book_lb.Location = new System.Drawing.Point(767, 306);
            this.Book_lb.Name = "Book_lb";
            this.Book_lb.Size = new System.Drawing.Size(50, 15);
            this.Book_lb.TabIndex = 10;
            this.Book_lb.Text = "Booked";
            this.Book_lb.Click += new System.EventHandler(this.Book_lb_Click);
            // 
            // bunifuElipse2
            // 
            this.bunifuElipse2.ElipseRadius = 8;
            this.bunifuElipse2.TargetControl = this;
            // 
            // bunifuElipse3
            // 
            this.bunifuElipse3.ElipseRadius = 8;
            this.bunifuElipse3.TargetControl = this;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(725, 450);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(61, 15);
            this.label6.TabIndex = 15;
            this.label6.Text = "Custormer";
            // 
            // Cusnum_lbl
            // 
            this.Cusnum_lbl.AutoSize = true;
            this.Cusnum_lbl.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cusnum_lbl.ForeColor = System.Drawing.Color.White;
            this.Cusnum_lbl.Location = new System.Drawing.Point(784, 475);
            this.Cusnum_lbl.Name = "Cusnum_lbl";
            this.Cusnum_lbl.Size = new System.Drawing.Size(34, 15);
            this.Cusnum_lbl.TabIndex = 17;
            this.Cusnum_lbl.Text = "Num";
            // 
            // Booknum_lbl
            // 
            this.Booknum_lbl.AutoSize = true;
            this.Booknum_lbl.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Booknum_lbl.ForeColor = System.Drawing.Color.White;
            this.Booknum_lbl.Location = new System.Drawing.Point(784, 525);
            this.Booknum_lbl.Name = "Booknum_lbl";
            this.Booknum_lbl.Size = new System.Drawing.Size(34, 15);
            this.Booknum_lbl.TabIndex = 20;
            this.Booknum_lbl.Text = "Num";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(725, 499);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(54, 15);
            this.label9.TabIndex = 18;
            this.label9.Text = "Bookings";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.LightGray;
            this.label10.Location = new System.Drawing.Point(205, 181);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(96, 21);
            this.label10.TabIndex = 21;
            this.label10.Text = "Rooms Plan";
            // 
            // bunifuElipse4
            // 
            this.bunifuElipse4.ElipseRadius = 25;
            this.bunifuElipse4.TargetControl = this.p01;
            // 
            // bunifuElipse5
            // 
            this.bunifuElipse5.ElipseRadius = 25;
            this.bunifuElipse5.TargetControl = this.p02;
            // 
            // bunifuElipse6
            // 
            this.bunifuElipse6.ElipseRadius = 25;
            this.bunifuElipse6.TargetControl = this.p03;
            // 
            // bunifuElipse7
            // 
            this.bunifuElipse7.ElipseRadius = 25;
            this.bunifuElipse7.TargetControl = this.p04;
            // 
            // bunifuElipse8
            // 
            this.bunifuElipse8.ElipseRadius = 25;
            this.bunifuElipse8.TargetControl = this.p05;
            // 
            // bunifuElipse9
            // 
            this.bunifuElipse9.ElipseRadius = 25;
            this.bunifuElipse9.TargetControl = this.p06;
            // 
            // bunifuElipse10
            // 
            this.bunifuElipse10.ElipseRadius = 25;
            this.bunifuElipse10.TargetControl = this.p07;
            // 
            // bunifuElipse11
            // 
            this.bunifuElipse11.ElipseRadius = 25;
            this.bunifuElipse11.TargetControl = this.p08;
            // 
            // bunifuElipse12
            // 
            this.bunifuElipse12.ElipseRadius = 25;
            this.bunifuElipse12.TargetControl = this.p09;
            // 
            // bunifuElipse13
            // 
            this.bunifuElipse13.ElipseRadius = 25;
            this.bunifuElipse13.TargetControl = this.p10;
            // 
            // bunifuElipse14
            // 
            this.bunifuElipse14.ElipseRadius = 25;
            this.bunifuElipse14.TargetControl = this.p11;
            // 
            // bunifuElipse15
            // 
            this.bunifuElipse15.ElipseRadius = 25;
            this.bunifuElipse15.TargetControl = this.p12;
            // 
            // bunifuElipse16
            // 
            this.bunifuElipse16.ElipseRadius = 25;
            this.bunifuElipse16.TargetControl = this.p13;
            // 
            // bunifuElipse17
            // 
            this.bunifuElipse17.ElipseRadius = 25;
            this.bunifuElipse17.TargetControl = this.p14;
            // 
            // bunifuElipse18
            // 
            this.bunifuElipse18.ElipseRadius = 25;
            this.bunifuElipse18.TargetControl = this.p15;
            // 
            // bunifuElipse19
            // 
            this.bunifuElipse19.ElipseRadius = 25;
            this.bunifuElipse19.TargetControl = this.p16;
            // 
            // bunifuElipse20
            // 
            this.bunifuElipse20.ElipseRadius = 25;
            this.bunifuElipse20.TargetControl = this.p17;
            // 
            // bunifuElipse21
            // 
            this.bunifuElipse21.ElipseRadius = 25;
            this.bunifuElipse21.TargetControl = this.p18;
            // 
            // bunifuElipse22
            // 
            this.bunifuElipse22.ElipseRadius = 25;
            this.bunifuElipse22.TargetControl = this.p19;
            // 
            // bunifuElipse23
            // 
            this.bunifuElipse23.ElipseRadius = 25;
            this.bunifuElipse23.TargetControl = this.p20;
            // 
            // bunifuElipse24
            // 
            this.bunifuElipse24.ElipseRadius = 25;
            this.bunifuElipse24.TargetControl = this.p21;
            // 
            // bunifuElipse25
            // 
            this.bunifuElipse25.ElipseRadius = 25;
            this.bunifuElipse25.TargetControl = this.p22;
            // 
            // bunifuElipse26
            // 
            this.bunifuElipse26.ElipseRadius = 25;
            this.bunifuElipse26.TargetControl = this.p23;
            // 
            // bunifuElipse27
            // 
            this.bunifuElipse27.ElipseRadius = 25;
            this.bunifuElipse27.TargetControl = this.p24;
            // 
            // pictureBox13
            // 
            this.pictureBox13.Image = global::Project06.Properties.Resources.images__1__removebg_preview1;
            this.pictureBox13.Location = new System.Drawing.Point(728, 394);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(25, 25);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox13.TabIndex = 54;
            this.pictureBox13.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::Project06.Properties.Resources._5a29a326cc6df1484b1ffad5d5539698_removebg_preview;
            this.pictureBox8.Location = new System.Drawing.Point(199, 10);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(44, 44);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox8.TabIndex = 53;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::Project06.Properties.Resources.profile01;
            this.pictureBox7.Location = new System.Drawing.Point(743, 517);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(30, 23);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox7.TabIndex = 19;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::Project06.Properties.Resources.profile01;
            this.pictureBox6.Location = new System.Drawing.Point(743, 468);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(30, 23);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 16;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::Project06.Properties.Resources.images__1__removebg_preview1;
            this.pictureBox5.Location = new System.Drawing.Point(728, 358);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(25, 25);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 13;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::Project06.Properties.Resources.ball01___Copy_removebg_preview;
            this.pictureBox4.Location = new System.Drawing.Point(725, 301);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(30, 23);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 8;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Project06.Properties.Resources.ball01_removebg_preview;
            this.pictureBox2.Location = new System.Drawing.Point(728, 264);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(23, 23);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 6;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.pictureBox3.BackgroundImage = global::Project06.Properties.Resources._8815105_removebg_preview;
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox3.Location = new System.Drawing.Point(42, 540);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(25, 25);
            this.pictureBox3.TabIndex = 84;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click_1);
            // 
            // freerooms_progress
            // 
            this.freerooms_progress.AnimationSpeed = 0.6F;
            this.freerooms_progress.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.freerooms_progress.Controls.Add(this.label12);
            this.freerooms_progress.Controls.Add(this.Avalbl1);
            this.freerooms_progress.IdleColor = System.Drawing.Color.Gainsboro;
            this.freerooms_progress.IdleOffset = 20;
            this.freerooms_progress.IdleThickness = 25;
            this.freerooms_progress.Image = null;
            this.freerooms_progress.ImageSize = new System.Drawing.Size(52, 52);
            this.freerooms_progress.Location = new System.Drawing.Point(725, 64);
            this.freerooms_progress.Name = "freerooms_progress";
            this.freerooms_progress.ProgressMaxColor = System.Drawing.Color.Crimson;
            this.freerooms_progress.ProgressMinColor = System.Drawing.Color.Gold;
            this.freerooms_progress.ProgressOffset = 20;
            this.freerooms_progress.ProgressThickness = 25;
            this.freerooms_progress.Size = new System.Drawing.Size(165, 171);
            this.freerooms_progress.TabIndex = 85;
            this.freerooms_progress.Click += new System.EventHandler(this.freerooms_progress_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Turquoise;
            this.label12.Location = new System.Drawing.Point(53, 82);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(62, 21);
            this.label12.TabIndex = 23;
            this.label12.Text = "Rooms";
            // 
            // Avalbl1
            // 
            this.Avalbl1.AutoSize = true;
            this.Avalbl1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Avalbl1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(173)))), ((int)(((byte)(143)))));
            this.Avalbl1.Location = new System.Drawing.Point(69, 61);
            this.Avalbl1.Name = "Avalbl1";
            this.Avalbl1.Size = new System.Drawing.Size(28, 21);
            this.Avalbl1.TabIndex = 22;
            this.Avalbl1.Text = "24";
            this.Avalbl1.Click += new System.EventHandler(this.Avalbl1_Click);
            // 
            // Ava_progress
            // 
            this.Ava_progress.BorderColor = System.Drawing.Color.Black;
            this.Ava_progress.ColorStyle = Guna.UI.WinForms.ColorStyle.Default;
            this.Ava_progress.IdleColor = System.Drawing.Color.Gainsboro;
            this.Ava_progress.Location = new System.Drawing.Point(759, 367);
            this.Ava_progress.Maximum = 24;
            this.Ava_progress.Name = "Ava_progress";
            this.Ava_progress.ProgressMaxColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(173)))), ((int)(((byte)(143)))));
            this.Ava_progress.ProgressMinColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(173)))), ((int)(((byte)(143)))));
            this.Ava_progress.Size = new System.Drawing.Size(159, 8);
            this.Ava_progress.TabIndex = 11;
            this.Ava_progress.Click += new System.EventHandler(this.Ava_progress_Click);
            // 
            // book_progress
            // 
            this.book_progress.BorderColor = System.Drawing.Color.Black;
            this.book_progress.ColorStyle = Guna.UI.WinForms.ColorStyle.Default;
            this.book_progress.IdleColor = System.Drawing.Color.Gainsboro;
            this.book_progress.Location = new System.Drawing.Point(759, 405);
            this.book_progress.Maximum = 24;
            this.book_progress.Name = "book_progress";
            this.book_progress.ProgressMaxColor = System.Drawing.Color.Turquoise;
            this.book_progress.ProgressMinColor = System.Drawing.Color.Turquoise;
            this.book_progress.Size = new System.Drawing.Size(159, 8);
            this.book_progress.TabIndex = 87;
            this.book_progress.Click += new System.EventHandler(this.book_progress_Click);
            // 
            // gunaElipse1
            // 
            this.gunaElipse1.Radius = 3;
            this.gunaElipse1.TargetControl = this.book_progress;
            // 
            // gunaElipse2
            // 
            this.gunaElipse2.Radius = 3;
            this.gunaElipse2.TargetControl = this.Ava_progress;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(824, 346);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(30, 15);
            this.label4.TabIndex = 88;
            this.label4.Text = "Paid";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(824, 387);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(54, 15);
            this.label5.TabIndex = 89;
            this.label5.Text = "Not Paid";
            // 
            // CusIDcb
            // 
            this.CusIDcb.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(79)))), ((int)(((byte)(99)))));
            this.CusIDcb.ForeColor = System.Drawing.Color.White;
            this.CusIDcb.FormattingEnabled = true;
            this.CusIDcb.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.CusIDcb.Location = new System.Drawing.Point(289, 133);
            this.CusIDcb.Name = "CusIDcb";
            this.CusIDcb.Size = new System.Drawing.Size(77, 21);
            this.CusIDcb.TabIndex = 90;
            this.CusIDcb.SelectionChangeCommitted += new System.EventHandler(this.CusIDcb_SelectionChangeCommitted);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(206, 134);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(77, 18);
            this.label7.TabIndex = 91;
            this.label7.Text = "Customer";
            // 
            // CusNametb
            // 
            this.CusNametb.BackColor = System.Drawing.Color.LightGray;
            this.CusNametb.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.CusNametb.Enabled = false;
            this.CusNametb.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CusNametb.ForeColor = System.Drawing.Color.Black;
            this.CusNametb.Location = new System.Drawing.Point(372, 134);
            this.CusNametb.Multiline = true;
            this.CusNametb.Name = "CusNametb";
            this.CusNametb.Size = new System.Drawing.Size(162, 20);
            this.CusNametb.TabIndex = 92;
            // 
            // btn_book
            // 
            this.btn_book.ActiveBorderThickness = 1;
            this.btn_book.ActiveCornerRadius = 20;
            this.btn_book.ActiveFillColor = System.Drawing.Color.SlateGray;
            this.btn_book.ActiveForecolor = System.Drawing.Color.White;
            this.btn_book.ActiveLineColor = System.Drawing.Color.SlateGray;
            this.btn_book.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.btn_book.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_book.BackgroundImage")));
            this.btn_book.ButtonText = "Book";
            this.btn_book.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_book.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_book.ForeColor = System.Drawing.Color.White;
            this.btn_book.IdleBorderThickness = 1;
            this.btn_book.IdleCornerRadius = 20;
            this.btn_book.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.btn_book.IdleForecolor = System.Drawing.Color.White;
            this.btn_book.IdleLineColor = System.Drawing.Color.White;
            this.btn_book.Location = new System.Drawing.Point(541, 130);
            this.btn_book.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_book.Name = "btn_book";
            this.btn_book.Size = new System.Drawing.Size(78, 30);
            this.btn_book.TabIndex = 93;
            this.btn_book.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_book.Click += new System.EventHandler(this.btn_book_Click);
            // 
            // Dashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.ClientSize = new System.Drawing.Size(951, 575);
            this.Controls.Add(this.btn_book);
            this.Controls.Add(this.CusNametb);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.CusIDcb);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.book_progress);
            this.Controls.Add(this.Ava_progress);
            this.Controls.Add(this.freerooms_progress);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox13);
            this.Controls.Add(this.pictureBox8);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.Booknum_lbl);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.Cusnum_lbl);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.Book_lb);
            this.Controls.Add(this.Ava_lb);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pnlnav);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Dashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Dashboard";
            this.Load += new System.EventHandler(this.Dashboard_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel3.ResumeLayout(false);
            this.p24.ResumeLayout(false);
            this.p24.PerformLayout();
            this.panel65.ResumeLayout(false);
            this.p20.ResumeLayout(false);
            this.p20.PerformLayout();
            this.panel41.ResumeLayout(false);
            this.p23.ResumeLayout(false);
            this.p23.PerformLayout();
            this.panel68.ResumeLayout(false);
            this.p12.ResumeLayout(false);
            this.p12.PerformLayout();
            this.panel29.ResumeLayout(false);
            this.p21.ResumeLayout(false);
            this.p21.PerformLayout();
            this.panel71.ResumeLayout(false);
            this.p22.ResumeLayout(false);
            this.p22.PerformLayout();
            this.panel74.ResumeLayout(false);
            this.p16.ResumeLayout(false);
            this.p16.PerformLayout();
            this.panel44.ResumeLayout(false);
            this.p08.ResumeLayout(false);
            this.p08.PerformLayout();
            this.panel17.ResumeLayout(false);
            this.p19.ResumeLayout(false);
            this.p19.PerformLayout();
            this.panel47.ResumeLayout(false);
            this.p11.ResumeLayout(false);
            this.p11.PerformLayout();
            this.panel32.ResumeLayout(false);
            this.p17.ResumeLayout(false);
            this.p17.PerformLayout();
            this.panel50.ResumeLayout(false);
            this.p04.ResumeLayout(false);
            this.p04.PerformLayout();
            this.panel14.ResumeLayout(false);
            this.p18.ResumeLayout(false);
            this.p18.PerformLayout();
            this.panel53.ResumeLayout(false);
            this.p09.ResumeLayout(false);
            this.p09.PerformLayout();
            this.panel35.ResumeLayout(false);
            this.p15.ResumeLayout(false);
            this.p15.PerformLayout();
            this.panel56.ResumeLayout(false);
            this.p10.ResumeLayout(false);
            this.p10.PerformLayout();
            this.panel38.ResumeLayout(false);
            this.p13.ResumeLayout(false);
            this.p13.PerformLayout();
            this.panel59.ResumeLayout(false);
            this.p14.ResumeLayout(false);
            this.p14.PerformLayout();
            this.panel62.ResumeLayout(false);
            this.p07.ResumeLayout(false);
            this.p07.PerformLayout();
            this.panel20.ResumeLayout(false);
            this.p03.ResumeLayout(false);
            this.p03.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.p05.ResumeLayout(false);
            this.p05.PerformLayout();
            this.panel23.ResumeLayout(false);
            this.p01.ResumeLayout(false);
            this.p01.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.p06.ResumeLayout(false);
            this.p06.PerformLayout();
            this.panel26.ResumeLayout(false);
            this.p02.ResumeLayout(false);
            this.p02.PerformLayout();
            this.panel8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.freerooms_progress.ResumeLayout(false);
            this.freerooms_progress.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btndashboard;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnlogout;
        private System.Windows.Forms.Button btnbooking;
        private System.Windows.Forms.Button btncustomer;
        private System.Windows.Forms.Button btnuser;
        private System.Windows.Forms.Panel pnlnav;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel3;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label Book_lb;
        private System.Windows.Forms.Label Ava_lb;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label Booknum_lbl;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label Cusnum_lbl;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Label label6;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse2;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse3;
        private System.Windows.Forms.Panel p24;
        private System.Windows.Forms.Panel panel65;
        private System.Windows.Forms.Panel panel66;
        private System.Windows.Forms.Panel p20;
        private System.Windows.Forms.Panel panel41;
        private System.Windows.Forms.Panel panel42;
        private System.Windows.Forms.Panel p23;
        private System.Windows.Forms.Panel panel68;
        private System.Windows.Forms.Panel panel69;
        private System.Windows.Forms.Panel p12;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.Panel panel30;
        private System.Windows.Forms.Panel p21;
        private System.Windows.Forms.Panel panel71;
        private System.Windows.Forms.Panel panel72;
        private System.Windows.Forms.Panel p22;
        private System.Windows.Forms.Panel panel74;
        private System.Windows.Forms.Panel panel75;
        private System.Windows.Forms.Panel p16;
        private System.Windows.Forms.Panel panel44;
        private System.Windows.Forms.Panel panel45;
        private System.Windows.Forms.Panel p08;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Panel p19;
        private System.Windows.Forms.Panel panel47;
        private System.Windows.Forms.Panel panel48;
        private System.Windows.Forms.Panel p11;
        private System.Windows.Forms.Panel panel32;
        private System.Windows.Forms.Panel panel33;
        private System.Windows.Forms.Panel p17;
        private System.Windows.Forms.Panel panel50;
        private System.Windows.Forms.Panel panel51;
        private System.Windows.Forms.Panel p04;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Panel p18;
        private System.Windows.Forms.Panel panel53;
        private System.Windows.Forms.Panel panel54;
        private System.Windows.Forms.Panel p09;
        private System.Windows.Forms.Panel panel35;
        private System.Windows.Forms.Panel panel36;
        private System.Windows.Forms.Panel p15;
        private System.Windows.Forms.Panel panel56;
        private System.Windows.Forms.Panel panel57;
        private System.Windows.Forms.Panel p10;
        private System.Windows.Forms.Panel panel38;
        private System.Windows.Forms.Panel panel39;
        private System.Windows.Forms.Panel p13;
        private System.Windows.Forms.Panel panel59;
        private System.Windows.Forms.Panel panel60;
        private System.Windows.Forms.Panel p14;
        private System.Windows.Forms.Panel panel62;
        private System.Windows.Forms.Panel panel63;
        private System.Windows.Forms.Panel p07;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Panel p03;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel p05;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.Panel p01;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel p06;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.Panel p02;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label label10;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse4;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse5;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse6;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse7;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse8;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse9;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse10;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse11;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse12;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse13;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse14;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse15;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse16;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse17;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse18;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse19;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse20;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse21;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse22;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse23;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse24;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse25;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse26;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse27;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.PictureBox pictureBox3;
        private Guna.UI.WinForms.GunaCircleProgressBar freerooms_progress;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label Avalbl1;
        private Guna.UI.WinForms.GunaProgressBar book_progress;
        private Guna.UI.WinForms.GunaProgressBar Ava_progress;
        private Guna.UI.WinForms.GunaElipse gunaElipse1;
        private Guna.UI.WinForms.GunaElipse gunaElipse2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox CusIDcb;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox CusNametb;
        private System.Windows.Forms.Label room24;
        private System.Windows.Forms.Label room20;
        private System.Windows.Forms.Label room23;
        private System.Windows.Forms.Label room12;
        private System.Windows.Forms.Label room21;
        private System.Windows.Forms.Label room22;
        private System.Windows.Forms.Label room16;
        private System.Windows.Forms.Label room8;
        private System.Windows.Forms.Label room19;
        private System.Windows.Forms.Label room11;
        private System.Windows.Forms.Label room17;
        private System.Windows.Forms.Label room4;
        private System.Windows.Forms.Label room18;
        private System.Windows.Forms.Label room9;
        private System.Windows.Forms.Label room15;
        private System.Windows.Forms.Label room10;
        private System.Windows.Forms.Label room13;
        private System.Windows.Forms.Label room14;
        private System.Windows.Forms.Label room7;
        private System.Windows.Forms.Label room3;
        private System.Windows.Forms.Label room5;
        private System.Windows.Forms.Label room1;
        private System.Windows.Forms.Label room6;
        private System.Windows.Forms.Label room2;
        private Bunifu.Framework.UI.BunifuThinButton2 btn_book;
    }
}