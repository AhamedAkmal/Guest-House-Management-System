﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Data.SqlClient;

namespace Project06
{
    public partial class Dashboard : Form
    {
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]

            private static extern IntPtr CreateRoundRectrgn
(
   int nLeftReact,
   int nTopReact,
   int nRightReact,
   int nBottomReact,
   int nWidthEllipse,
   int nHeightEllipse
);

        public Dashboard()
        {
            InitializeComponent();
            CountBooked();
            CountCustomers();
            CountBookings();
            GetCustomer();
            CountBooks();

            Region = System.Drawing.Region.FromHrgn(CreateRoundRectrgn(0, 0, Width, Height, 25, 25));
            pnlnav.Height = btndashboard.Height;
            pnlnav.Top = btndashboard.Top;
            pnlnav.Left = btndashboard.Left;
            btndashboard.BackColor = Color.FromArgb(44, 51, 73);
        }
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-L0DRGMJ;Initial Catalog=GuestHouseDB;Integrated Security=True");
        int free, Booked;
        int Bper, Freeper;
        private void CountBooked()
        {
            string Status = "Booked";
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("Select Count(*) from RoomTbl Where RStatus='" + Status + "'", con);
            DataTable dt1 = new DataTable();
            sda.Fill(dt1);
            free = 24 - Convert.ToInt32(dt1.Rows[0][0].ToString());
            Booked = Convert.ToInt32(dt1.Rows[0][0].ToString());
            Bper = (Booked / 24)*100;
            Freeper = (free / 24)*100;
            Book_lb.Text = dt1.Rows[0][0].ToString()+"  Booked Rooms";
            Ava_lb.Text = free + " Rooms";
            Avalbl1.Text = free+"";

            book_progress.Value = Convert.ToInt32(Convert.ToInt32(dt1.Rows[0][0].ToString())*5);
            Ava_progress.Value = Convert.ToInt32(free*5);
            freerooms_progress.Value = Convert.ToInt32(free*5);
            con.Close();
        }

        private void CountCustomers()
        {
            
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("Select Count(*) from CustomerTbl", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
 
            Cusnum_lbl.Text = dt.Rows[0][0].ToString() + "  Customers";
            con.Close();
        }

        private void CountBookings()
        {

            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("Select Count(*) from BookingTbl", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);

            Booknum_lbl.Text = dt.Rows[0][0].ToString() + "  Rooms";
            con.Close();
        }

        private void CountBooks()
        {

            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("Select Count(*) from BookingTbl", con);
            DataTable dt1 = new DataTable();
            sda.Fill(dt1);

            Book_lb.Text = dt1.Rows[0][0].ToString() + "  Booked";
            con.Close();
        }

        private void Dashboard_Load(object sender, EventArgs e)
        {
            
            
            

        }

        private void btndashboard_Click(object sender, EventArgs e)
        {
            pnlnav.Height = btndashboard.Height;
            pnlnav.Top = btndashboard.Top;
            pnlnav.Left = btndashboard.Left;
            btndashboard.BackColor = Color.FromArgb(44, 51, 73);

            
            Dashboard obj = new Dashboard();
            obj.Show();
            this.Hide();
        }

        private void btnroom_Click(object sender, EventArgs e)
        {
            pnlnav.Height = btnuser.Height;
            pnlnav.Top = btnuser.Top;
            btnuser.BackColor = Color.FromArgb(44, 51, 73);

            
            Users obj = new Users();
            obj.Show();
            this.Hide();

        }

        private void btncustomer_Click(object sender, EventArgs e)
        {
            pnlnav.Height = btncustomer.Height;
            pnlnav.Top = btncustomer.Top;
            btncustomer.BackColor = Color.FromArgb(44, 51, 73);

            
            Customer obj = new Customer();
            obj.Show();
            this.Hide();
        }

        private void btnbooking_Click(object sender, EventArgs e)
        {
            pnlnav.Height = btnbooking.Height;
            pnlnav.Top = btnbooking.Top;
            btnbooking.BackColor = Color.FromArgb(44, 51, 73);

            
            Bookings obj = new Bookings();
            obj.Show();
            this.Hide();
        }

        private void btnlogout_Click(object sender, EventArgs e)
        {
            pnlnav.Height = btnlogout.Height;
            pnlnav.Top = btnlogout.Top;
            btnlogout.BackColor = Color.FromArgb(44, 51, 73);

            
            frm_login obj = new frm_login();
            obj.Show();
            this.Hide();
        }

        private void btndashboard_Leave(object sender, EventArgs e)
        {
            btndashboard.BackColor = Color.FromArgb(24, 30, 54);
        }

        private void btnroom_Leave(object sender, EventArgs e)
        {
            btnuser.BackColor = Color.FromArgb(24, 30, 54);
        }

        private void btncustomer_Leave(object sender, EventArgs e)
        {
            btncustomer.BackColor = Color.FromArgb(24, 30, 54);
        }

        private void btnbooking_Leave(object sender, EventArgs e)
        {
            btnbooking.BackColor = Color.FromArgb(24, 30, 54);
        }

        private void btnlogout_Leave(object sender, EventArgs e)
        {
            btnlogout.BackColor = Color.FromArgb(24, 30, 54);
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click_1(object sender, EventArgs e)
        {

        }

        private void GetCustomer()
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("Select CusID From CustomerTbl", con);
            SqlDataReader rdr;
            rdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("CusID", typeof(int));
            dt.Load(rdr);
            CusIDcb.ValueMember = "CusID";
            CusIDcb.DataSource = dt;
            con.Close();
        }

        int RoomNumber = 0;
        private void GetCusName()
        {
            con.Open();
            string Query = "Select * from CustomerTbl where CusID=" + CusIDcb.SelectedValue.ToString() + "";
            SqlCommand cmd = new SqlCommand(Query, con);
            DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            sda.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                CusNametb.Text = dr["CusName"].ToString();
            }
            con.Close();
        }

        string RType;
        int RC;
        private void GetRoomeType()
        {
            con.Open();
            string Query = "Select * from RoomTbl where RId=" + RoomNumber + "";
            SqlCommand cmd = new SqlCommand(Query, con);
            DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            sda.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
               RType = dr["RType"].ToString();
               RC = Convert.ToInt32(dr["RCost"].ToString());
            }
            con.Close();
        }

        private void Reset()
        {
            RType = "";
            RC = 0;
            RoomNumber = 0;
        }

        private void Updateroom()
        {
            string Status = "Booked";
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Update RoomTbl Set RStatus=@RS Where RId =@RKey", con);
                cmd.Parameters.AddWithValue("@RS", Status);
                cmd.Parameters.AddWithValue("@RKey", RoomNumber);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Room Updated");
                con.Close();
                Reset();
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
        }

        private void btn_book_Click(object sender, EventArgs e)
        {
            if (CusNametb.Text == "" || RoomNumber == 0)
            {
                MessageBox.Show("Select a Room and a Customer");
            }
            else
            {
                try
                {
                    GetRoomeType();
                    con.Open();
                    SqlCommand cmd = new SqlCommand("insert into BookingTbl(CusID,CusName,RId,RNumber,RType,RCost)values(@CI,@CN,@RI,@RN,@RT,@RC)", con);
                    cmd.Parameters.AddWithValue("@CI", CusIDcb.SelectedValue.ToString());
                    cmd.Parameters.AddWithValue("@CN", CusNametb.Text);
                    cmd.Parameters.AddWithValue("@RI", RoomNumber);
                    cmd.Parameters.AddWithValue("@RN", RoomNumber);
                    cmd.Parameters.AddWithValue("@RT", RType);
                    cmd.Parameters.AddWithValue("@RC", RC);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Room Booked");
                    Reset();
                    con.Close();
                    Updateroom();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }

            }
        }

        private void CusIDcb_SelectionChangeCommitted(object sender, EventArgs e)
        {
            GetCusName();
        }

        private void p01_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void p02_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void p03_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void room4_Click(object sender, EventArgs e)
        {
           
        }

        private void p05_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void p06_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void p07_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void p08_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void p09_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void p10_Paint(object sender, PaintEventArgs e)
        {
           
        }

        private void p11_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void p12_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void p13_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void p14_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void p15_Paint(object sender, PaintEventArgs e)
        {
           
        }

        private void p16_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void p17_Paint(object sender, PaintEventArgs e)
        {
           
        }

        private void p18_Paint(object sender, PaintEventArgs e)
        {
         
        }

        private void p19_Paint(object sender, PaintEventArgs e)
        {
           
        }

        private void p20_Paint(object sender, PaintEventArgs e)
        {
          
        }

        private void p21_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void p22_Paint(object sender, PaintEventArgs e)
        {
           
        }

        private void p23_Paint(object sender, PaintEventArgs e)
        {
  
        }

        private void p24_Paint(object sender, PaintEventArgs e)
        {

        }

        private void p01_Click(object sender, EventArgs e)
        {
            RoomNumber = 1;
        }

        private void p02_Click(object sender, EventArgs e)
        {
            RoomNumber = 2;
        }

        private void p03_Click(object sender, EventArgs e)
        {
            RoomNumber = 3;
        }

        private void p04_Click(object sender, EventArgs e)
        {
            RoomNumber = 4;
        }

        private void p05_Click(object sender, EventArgs e)
        {
            RoomNumber = 5;
        }

        private void p06_Click(object sender, EventArgs e)
        {
            RoomNumber = 6;
        }

        private void p07_Click(object sender, EventArgs e)
        {
            RoomNumber = 7;
        }

        private void p08_Click(object sender, EventArgs e)
        {
            RoomNumber = 8;
        }

        private void p09_Click(object sender, EventArgs e)
        {
            RoomNumber = 9;
        }

        private void p10_Click(object sender, EventArgs e)
        {
            RoomNumber = 10;
        }

        private void p11_Click(object sender, EventArgs e)
        {
            RoomNumber = 11;
        }

        private void p12_Click(object sender, EventArgs e)
        {
            RoomNumber = 12;
        }

        private void p13_Click(object sender, EventArgs e)
        {
            RoomNumber = 13;
        }

        private void p14_Click(object sender, EventArgs e)
        {
            RoomNumber = 14;
        }

        private void p15_Click(object sender, EventArgs e)
        {
            RoomNumber = 15;
        }

        private void p16_Click(object sender, EventArgs e)
        {
            RoomNumber = 16;
        }

        private void p17_Click(object sender, EventArgs e)
        {
            RoomNumber = 17;
        }

        private void p18_Click(object sender, EventArgs e)
        {
            RoomNumber = 18;
        }

        private void p19_Click(object sender, EventArgs e)
        {
            RoomNumber = 19;
        }

        private void p20_Click(object sender, EventArgs e)
        {
            RoomNumber = 20;
        }

        private void p21_Click(object sender, EventArgs e)
        {
            RoomNumber = 21;
        }

        private void p22_Click(object sender, EventArgs e)
        {
            RoomNumber = 22;
        }

        private void p23_Click(object sender, EventArgs e)
        {
            RoomNumber = 23;
        }

        private void p24_Click(object sender, EventArgs e)
        {
            RoomNumber = 24;
        }

        private void book_progress_Click(object sender, EventArgs e)
        {

        }

        private void freerooms_progress_Click(object sender, EventArgs e)
        {

        }

        private void Ava_progress_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {
            
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Book_lb_Click(object sender, EventArgs e)
        {

        }

        private void Avalbl1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
