﻿namespace Project06
{
    partial class frm_login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.user_txt = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.Email_txt = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.Pass_txt = new System.Windows.Forms.TextBox();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.button3 = new System.Windows.Forms.Button();
            this.timer3 = new System.Windows.Forms.Timer(this.components);
            this.timer4 = new System.Windows.Forms.Timer(this.components);
            this.timer5 = new System.Windows.Forms.Timer(this.components);
            this.timer6 = new System.Windows.Forms.Timer(this.components);
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.picuser = new System.Windows.Forms.PictureBox();
            this.picgoog = new System.Windows.Forms.PictureBox();
            this.picface = new System.Windows.Forms.PictureBox();
            this.picpass = new System.Windows.Forms.PictureBox();
            this.picemail = new System.Windows.Forms.PictureBox();
            this.logo = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picuser)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picgoog)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picface)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picpass)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picemail)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.logo)).BeginInit();
            this.SuspendLayout();
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 30;
            this.bunifuElipse1.TargetControl = this;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(35, 128);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(250, 1);
            this.panel1.TabIndex = 16;
            // 
            // user_txt
            // 
            this.user_txt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.user_txt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.user_txt.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.user_txt.ForeColor = System.Drawing.Color.DimGray;
            this.user_txt.HideSelection = false;
            this.user_txt.Location = new System.Drawing.Point(72, 103);
            this.user_txt.Name = "user_txt";
            this.user_txt.Size = new System.Drawing.Size(213, 19);
            this.user_txt.TabIndex = 11;
            this.user_txt.TabStop = false;
            this.user_txt.Text = "Username";
            this.user_txt.Click += new System.EventHandler(this.textBox1_Click);
            this.user_txt.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Location = new System.Drawing.Point(35, 246);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(250, 1);
            this.panel2.TabIndex = 21;
            // 
            // Email_txt
            // 
            this.Email_txt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.Email_txt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Email_txt.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Email_txt.ForeColor = System.Drawing.Color.DimGray;
            this.Email_txt.HideSelection = false;
            this.Email_txt.Location = new System.Drawing.Point(72, 221);
            this.Email_txt.Name = "Email_txt";
            this.Email_txt.Size = new System.Drawing.Size(213, 19);
            this.Email_txt.TabIndex = 20;
            this.Email_txt.TabStop = false;
            this.Email_txt.Text = "E-mail";
            this.Email_txt.Click += new System.EventHandler(this.textBox2_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Location = new System.Drawing.Point(35, 187);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(250, 1);
            this.panel3.TabIndex = 24;
            // 
            // Pass_txt
            // 
            this.Pass_txt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.Pass_txt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Pass_txt.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pass_txt.ForeColor = System.Drawing.Color.DimGray;
            this.Pass_txt.HideSelection = false;
            this.Pass_txt.Location = new System.Drawing.Point(72, 162);
            this.Pass_txt.Name = "Pass_txt";
            this.Pass_txt.Size = new System.Drawing.Size(213, 19);
            this.Pass_txt.TabIndex = 23;
            this.Pass_txt.TabStop = false;
            this.Pass_txt.Text = "Password";
            this.Pass_txt.Click += new System.EventHandler(this.textBox3_Click);
            // 
            // linkLabel1
            // 
            this.linkLabel1.ActiveLinkColor = System.Drawing.Color.Yellow;
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel1.LinkColor = System.Drawing.Color.White;
            this.linkLabel1.Location = new System.Drawing.Point(136, 338);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(44, 16);
            this.linkLabel1.TabIndex = 31;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Admin";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.White;
            this.panel4.Location = new System.Drawing.Point(34, 399);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(260, 1);
            this.panel4.TabIndex = 22;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(108, 380);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(96, 16);
            this.label1.TabIndex = 36;
            this.label1.Text = "Or Sign In With";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(72, 287);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(180, 40);
            this.button1.TabIndex = 39;
            this.button1.Text = "Login";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // timer1
            // 
            this.timer1.Interval = 10;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Interval = 10;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // button3
            // 
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(289, 12);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(25, 25);
            this.button3.TabIndex = 41;
            this.button3.Text = "X";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // timer3
            // 
            this.timer3.Interval = 10;
            this.timer3.Tick += new System.EventHandler(this.timer3_Tick);
            // 
            // timer4
            // 
            this.timer4.Interval = 10;
            this.timer4.Tick += new System.EventHandler(this.timer4_Tick);
            // 
            // timer5
            // 
            this.timer5.Interval = 10;
            this.timer5.Tick += new System.EventHandler(this.timer5_Tick);
            // 
            // timer6
            // 
            this.timer6.Interval = 10;
            this.timer6.Tick += new System.EventHandler(this.timer6_Tick);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox2.Image = global::Project06.Properties.Resources.twit001;
            this.pictureBox2.Location = new System.Drawing.Point(226, 401);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(68, 51);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 65;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // picuser
            // 
            this.picuser.BackgroundImage = global::Project06.Properties.Resources.profile02;
            this.picuser.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.picuser.Location = new System.Drawing.Point(34, 98);
            this.picuser.Name = "picuser";
            this.picuser.Size = new System.Drawing.Size(24, 24);
            this.picuser.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picuser.TabIndex = 37;
            this.picuser.TabStop = false;
            // 
            // picgoog
            // 
            this.picgoog.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picgoog.Image = global::Project06.Properties.Resources.google_logo1;
            this.picgoog.Location = new System.Drawing.Point(143, 411);
            this.picgoog.Name = "picgoog";
            this.picgoog.Size = new System.Drawing.Size(35, 35);
            this.picgoog.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picgoog.TabIndex = 35;
            this.picgoog.TabStop = false;
            this.picgoog.Click += new System.EventHandler(this.picgoog_Click);
            // 
            // picface
            // 
            this.picface.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picface.Image = global::Project06.Properties.Resources.Facebooklogo1;
            this.picface.Location = new System.Drawing.Point(35, 408);
            this.picface.Name = "picface";
            this.picface.Size = new System.Drawing.Size(38, 38);
            this.picface.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picface.TabIndex = 34;
            this.picface.TabStop = false;
            this.picface.Click += new System.EventHandler(this.picface_Click);
            // 
            // picpass
            // 
            this.picpass.BackgroundImage = global::Project06.Properties.Resources.Lock02;
            this.picpass.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picpass.Location = new System.Drawing.Point(34, 157);
            this.picpass.Name = "picpass";
            this.picpass.Size = new System.Drawing.Size(24, 24);
            this.picpass.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picpass.TabIndex = 25;
            this.picpass.TabStop = false;
            // 
            // picemail
            // 
            this.picemail.BackgroundImage = global::Project06.Properties.Resources.Mail02;
            this.picemail.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.picemail.Location = new System.Drawing.Point(34, 216);
            this.picemail.Name = "picemail";
            this.picemail.Size = new System.Drawing.Size(30, 30);
            this.picemail.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picemail.TabIndex = 22;
            this.picemail.TabStop = false;
            // 
            // logo
            // 
            this.logo.Image = global::Project06.Properties.Resources._5a29a326cc6df1484b1ffad5d5539698_removebg_preview;
            this.logo.Location = new System.Drawing.Point(139, 12);
            this.logo.Name = "logo";
            this.logo.Size = new System.Drawing.Size(64, 64);
            this.logo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.logo.TabIndex = 13;
            this.logo.TabStop = false;
            // 
            // frm_login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(326, 481);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.picuser);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.picgoog);
            this.Controls.Add(this.picface);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.picpass);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.Pass_txt);
            this.Controls.Add(this.picemail);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.Email_txt);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.user_txt);
            this.Controls.Add(this.logo);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "frm_login";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Login";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.frm_login_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picuser)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picgoog)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picface)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picpass)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picemail)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.logo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox user_txt;
        private System.Windows.Forms.PictureBox logo;
        private System.Windows.Forms.PictureBox picpass;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox Pass_txt;
        private System.Windows.Forms.PictureBox picemail;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox Email_txt;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.PictureBox picgoog;
        private System.Windows.Forms.PictureBox picface;
        private System.Windows.Forms.PictureBox picuser;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Timer timer3;
        private System.Windows.Forms.Timer timer4;
        private System.Windows.Forms.Timer timer5;
        private System.Windows.Forms.Timer timer6;

    }
}

