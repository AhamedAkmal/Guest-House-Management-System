﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project06
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            

            
        }

        private void picface_Click(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {
        }
            

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            

            
        }

        
        private void txt_username_Click(object sender, EventArgs e)
        {
            user_txt.Clear();
            picuser1.BackgroundImage = Project06.Properties.Resources.profile01;
            panel01.BackColor = Color.FromArgb(226, 183, 141);
            user_txt.ForeColor = Color.FromArgb(226, 183, 141);


            picpass1.BackgroundImage = Project06.Properties.Resources.Lock02;
            panel03.BackColor = Color.WhiteSmoke;
            Pass_txt.ForeColor = Color.WhiteSmoke;

        }

        private void txt_pass_Click(object sender, EventArgs e)
        {
            Pass_txt.Clear();
            Pass_txt.PasswordChar = '*';
            picpass1.BackgroundImage = Project06.Properties.Resources.Lock01;
            panel03.BackColor = Color.FromArgb(226, 183, 141);
            Pass_txt.ForeColor = Color.FromArgb(226, 183, 141);


            picuser1.BackgroundImage = Project06.Properties.Resources.profile02;
            panel01.BackColor = Color.WhiteSmoke;
            user_txt.ForeColor = Color.WhiteSmoke;

        }

        private void picgoog_Click(object sender, EventArgs e)
        {
            
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
           

        }

        private void timer1_Tick_1(object sender, EventArgs e)
        {
            

        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            
        }

        private void timer4_Tick(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm_login obj = new frm_login();
            obj.Show();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            
        }

        private void timer2_Tick_1(object sender, EventArgs e)
        {

        }
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-L0DRGMJ;Initial Catalog=GuestHouseDB;Integrated Security=True");
        private void button1_Click(object sender, EventArgs e)
        {
            if (user_txt.Text == "" || Pass_txt.Text == "")
            {
                MessageBox.Show("Enter UserName and Password");
            }
            else
            {
                try
                {
                    con.Open();
                    SqlDataAdapter sda = new SqlDataAdapter("select Count(*) from UserTbl Where UserName='" + user_txt.Text + "' and UserPass='" + Pass_txt.Text + "'", con);
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    if (dt.Rows[0][0].ToString() == "1")
                    {
                        Dashboard obj = new Dashboard();
                        obj.Show();
                        this.Hide();
                        con.Close();
                    }
                    else
                    {
                        MessageBox.Show("Wrong UserName And Password");
                    }
                    con.Close();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }
    }
}
