﻿namespace Project06
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.button2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.picgoog = new System.Windows.Forms.PictureBox();
            this.picface = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.picuser = new System.Windows.Forms.PictureBox();
            this.picpass = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.Pass_txt = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.bunifuElipse2 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.user_txt = new System.Windows.Forms.TextBox();
            this.logo = new System.Windows.Forms.PictureBox();
            this.bunifuElipse3 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picgoog)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picface)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picuser)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picpass)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.logo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 30;
            this.bunifuElipse1.TargetControl = this;
            // 
            // timer2
            // 
            this.timer2.Interval = 10;
            // 
            // button2
            // 
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(289, 12);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(25, 25);
            this.button2.TabIndex = 79;
            this.button2.Text = "X";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(112, 380);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 16);
            this.label1.TabIndex = 77;
            this.label1.Text = "Or Sign In With";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.White;
            this.panel4.Location = new System.Drawing.Point(38, 400);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(260, 1);
            this.panel4.TabIndex = 74;
            // 
            // picgoog
            // 
            this.picgoog.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picgoog.Image = global::Project06.Properties.Resources.google_logo1;
            this.picgoog.Location = new System.Drawing.Point(138, 407);
            this.picgoog.Name = "picgoog";
            this.picgoog.Size = new System.Drawing.Size(44, 44);
            this.picgoog.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picgoog.TabIndex = 76;
            this.picgoog.TabStop = false;
            // 
            // picface
            // 
            this.picface.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picface.Image = global::Project06.Properties.Resources.Facebooklogo1;
            this.picface.Location = new System.Drawing.Point(39, 407);
            this.picface.Name = "picface";
            this.picface.Size = new System.Drawing.Size(44, 44);
            this.picface.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picface.TabIndex = 75;
            this.picface.TabStop = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(73, 255);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(180, 40);
            this.button1.TabIndex = 73;
            this.button1.Text = "Sign In with Twitter";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // picuser
            // 
            this.picuser.BackgroundImage = global::Project06.Properties.Resources.profile02;
            this.picuser.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.picuser.Location = new System.Drawing.Point(35, 125);
            this.picuser.Name = "picuser";
            this.picuser.Size = new System.Drawing.Size(24, 24);
            this.picuser.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picuser.TabIndex = 72;
            this.picuser.TabStop = false;
            // 
            // picpass
            // 
            this.picpass.BackgroundImage = global::Project06.Properties.Resources.Lock02;
            this.picpass.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picpass.Location = new System.Drawing.Point(35, 184);
            this.picpass.Name = "picpass";
            this.picpass.Size = new System.Drawing.Size(24, 24);
            this.picpass.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picpass.TabIndex = 71;
            this.picpass.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Location = new System.Drawing.Point(36, 214);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(250, 1);
            this.panel3.TabIndex = 70;
            // 
            // Pass_txt
            // 
            this.Pass_txt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.Pass_txt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Pass_txt.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pass_txt.ForeColor = System.Drawing.Color.DimGray;
            this.Pass_txt.HideSelection = false;
            this.Pass_txt.Location = new System.Drawing.Point(73, 189);
            this.Pass_txt.Name = "Pass_txt";
            this.Pass_txt.Size = new System.Drawing.Size(213, 19);
            this.Pass_txt.TabIndex = 69;
            this.Pass_txt.TabStop = false;
            this.Pass_txt.Text = "Password";
            this.Pass_txt.Click += new System.EventHandler(this.t_pass_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(36, 155);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(250, 1);
            this.panel1.TabIndex = 68;
            // 
            // timer1
            // 
            this.timer1.Interval = 10;
            // 
            // bunifuElipse2
            // 
            this.bunifuElipse2.ElipseRadius = 30;
            this.bunifuElipse2.TargetControl = this;
            // 
            // user_txt
            // 
            this.user_txt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.user_txt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.user_txt.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.user_txt.ForeColor = System.Drawing.Color.DimGray;
            this.user_txt.HideSelection = false;
            this.user_txt.Location = new System.Drawing.Point(73, 130);
            this.user_txt.Name = "user_txt";
            this.user_txt.Size = new System.Drawing.Size(213, 19);
            this.user_txt.TabIndex = 66;
            this.user_txt.TabStop = false;
            this.user_txt.Text = "Username";
            this.user_txt.Click += new System.EventHandler(this.t_user_Click);
            // 
            // logo
            // 
            this.logo.Image = global::Project06.Properties.Resources.twit001;
            this.logo.Location = new System.Drawing.Point(134, 12);
            this.logo.Name = "logo";
            this.logo.Size = new System.Drawing.Size(64, 64);
            this.logo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.logo.TabIndex = 67;
            this.logo.TabStop = false;
            // 
            // bunifuElipse3
            // 
            this.bunifuElipse3.ElipseRadius = 30;
            this.bunifuElipse3.TargetControl = this;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox2.Image = global::Project06.Properties.Resources.twitterlogo1;
            this.pictureBox2.Location = new System.Drawing.Point(226, 401);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(68, 51);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 80;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.ClientSize = new System.Drawing.Size(326, 481);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.picgoog);
            this.Controls.Add(this.picface);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.picuser);
            this.Controls.Add(this.picpass);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.Pass_txt);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.user_txt);
            this.Controls.Add(this.logo);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Form4";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form4";
            ((System.ComponentModel.ISupportInitialize)(this.picgoog)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picface)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picuser)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picpass)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.logo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.PictureBox picgoog;
        private System.Windows.Forms.PictureBox picface;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox picuser;
        private System.Windows.Forms.PictureBox picpass;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox Pass_txt;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox user_txt;
        private System.Windows.Forms.PictureBox logo;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Timer timer1;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse2;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse3;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}