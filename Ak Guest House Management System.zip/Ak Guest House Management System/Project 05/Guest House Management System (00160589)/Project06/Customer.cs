﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Data.SqlClient;


namespace Project06
{
    public partial class Customer : Form
    {
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]

        private static extern IntPtr CreateRoundRectrgn
(
int nLeftReact,
int nTopReact,
int nRightReact,
int nBottomReact,
int nWidthEllipse,
int nHeightEllipse
);
        public Customer()
        {
            InitializeComponent();
            ShowCustomers();

            Region = System.Drawing.Region.FromHrgn(CreateRoundRectrgn(0, 0, Width, Height, 25, 25));
            panel4.Height = btncustomer.Height;
            panel4.Top = btncustomer.Top;
            panel4.Left = btncustomer.Left;
            btncustomer.BackColor = Color.FromArgb(44, 51, 73);
        }

        private void Customer_Load(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void btndashboard_Click(object sender, EventArgs e)
        {
            panel4.Height = btndashboard.Height;
            panel4.Top = btndashboard.Top;
            panel4.Left = btndashboard.Left;
            btndashboard.BackColor = Color.FromArgb(44, 51, 73);

            
            Dashboard obj = new Dashboard();
            obj.Show();
            this.Hide();

        }

        private void btnuser_Click(object sender, EventArgs e)
        {
            panel4.Height = btnuser.Height;
            panel4.Top = btnuser.Top;
            btnuser.BackColor = Color.FromArgb(44, 51, 73);

            
            Users obj = new Users();
            obj.Show();
            this.Hide();

        }

        private void btncustomer_Click(object sender, EventArgs e)
        {
            panel4.Height = btncustomer.Height;
            panel4.Top = btncustomer.Top;
            btncustomer.BackColor = Color.FromArgb(44, 51, 73);

           
            Customer obj = new Customer();
            obj.Show();
            this.Hide();
        }

        private void btnbooking_Click(object sender, EventArgs e)
        {
            panel4.Height = btnbooking.Height;
            panel4.Top = btnbooking.Top;
            btnbooking.BackColor = Color.FromArgb(44, 51, 73);

            
            Bookings obj = new Bookings();
            obj.Show();
            this.Hide();
        }

        private void btnlogout_Click(object sender, EventArgs e)
        {
            panel4.Height = btnlogout.Height;
            panel4.Top = btnlogout.Top;
            btnlogout.BackColor = Color.FromArgb(44, 51, 73);

            
            frm_login obj = new frm_login();
            obj.Show();
            this.Hide();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void btndashboard_Leave(object sender, EventArgs e)
        {
            btndashboard.BackColor = Color.FromArgb(24, 30, 54);
        }

        private void btnuser_Leave(object sender, EventArgs e)
        {
            btnuser.BackColor = Color.FromArgb(24, 30, 54);

        }

        private void btncustomer_Leave(object sender, EventArgs e)
        {
            btncustomer.BackColor = Color.FromArgb(24, 30, 54);

        }

        private void btnbooking_Leave(object sender, EventArgs e)
        {
            btnbooking.BackColor = Color.FromArgb(24, 30, 54);
        }

        private void btnlogout_Leave(object sender, EventArgs e)
        {
            btnlogout.BackColor = Color.FromArgb(24, 30, 54);

        }

        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-L0DRGMJ;Initial Catalog=GuestHouseDB;Integrated Security=True");
        private void ShowCustomers()
        {
            con.Open();
            string Query = "Select * From CustomerTbl";
            SqlDataAdapter sda = new SqlDataAdapter(Query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            CustomerDGV.DataSource = ds.Tables[0];
            con.Close();
        }

        private void Reset()
        {
            CusNametxt.Text = "";
            Cusphonetxt.Text = "";
            CusGendertxt.SelectedIndex = -1;
            Key = 0;
        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            if (CusNametxt.Text == "" || Cusphonetxt.Text == "" || CusGendertxt.SelectedIndex == -1)
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("insert into CustomerTbl(CusName,CusPhone,CusGen,CusDOB)values(@CN,@CP,@CG,@CD)", con);
                    cmd.Parameters.AddWithValue("@CN", CusNametxt.Text);
                    cmd.Parameters.AddWithValue("@CP", Cusphonetxt.Text);
                    cmd.Parameters.AddWithValue("@CG", CusGendertxt.SelectedItem.ToString());
                    cmd.Parameters.AddWithValue("@CD", Cusdobtxt.Value.Date);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Customer Saved");
                    con.Close();
                    ShowCustomers();
                    Reset();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }
        int Key = 0;
        private void CustomerDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            CusNametxt.Text = CustomerDGV.SelectedRows[0].Cells[1].Value.ToString();
            Cusphonetxt.Text = CustomerDGV.SelectedRows[0].Cells[2].Value.ToString();
            CusGendertxt.Text = CustomerDGV.SelectedRows[0].Cells[3].Value.ToString();
            Cusdobtxt.Text = CustomerDGV.SelectedRows[0].Cells[4].Value.ToString();
            if (CusNametxt.Text == "")
            {
                Key = 0;
            }
            else
            {
                Key = Convert.ToInt32(CustomerDGV.SelectedRows[0].Cells[0].Value.ToString());
            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            {
                if (Key == 0)
                {
                    MessageBox.Show("Select Customer");
                }
                else
                {
                    try
                    {
                        con.Open();
                        SqlCommand cmd = new SqlCommand("Delete From Customertbl Where CusId=@CKey", con);
                        cmd.Parameters.AddWithValue("@CKey", Key);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Customer Deleted");
                        con.Close();
                        ShowCustomers();
                        Reset();
                    }
                    catch (Exception Ex)
                    {
                        MessageBox.Show(Ex.Message);
                    }
                }
            }
        }

        private void btn_edit_Click(object sender, EventArgs e)
        {
            if (CusNametxt.Text == "" || Cusphonetxt.Text == "" || CusGendertxt.SelectedIndex == -1)
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("Update CustomerTbl Set CusName=@CN,CusPhone=@CP,CusGen=@CG,CusDOB=@CD Where CusId =@CKey)", con);
                    cmd.Parameters.AddWithValue("@CN", CusNametxt.Text);
                    cmd.Parameters.AddWithValue("@CP", Cusphonetxt.Text);
                    cmd.Parameters.AddWithValue("@CG", CusGendertxt.SelectedItem.ToString());
                    cmd.Parameters.AddWithValue("@CD", Cusdobtxt.Value.Date);
                    cmd.Parameters.AddWithValue("@CKey", Key);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Customer Updated");
                    con.Close();
                    ShowCustomers();
                    Reset();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
