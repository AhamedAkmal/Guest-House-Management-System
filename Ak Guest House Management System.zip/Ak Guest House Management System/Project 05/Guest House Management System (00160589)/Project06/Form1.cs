﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project06
{
    public partial class frm_login : Form
    {
        public frm_login()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void frm_login_Load(object sender, EventArgs e)
        {
            frm2.Show();
            frm3.Show();
            frm4.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Dashboard obj = new Dashboard();
            obj.Show();
        }

        
        Form2 frm2 = new Form2();
        Form3 frm3 = new Form3();
        Form4 frm4 = new Form4();
        


        private void textBox1_Click(object sender, EventArgs e)
        {
            user_txt.Clear();
            picuser.BackgroundImage = Project06.Properties.Resources.profile01;
            panel1.BackColor = Color.FromArgb(226, 183, 141);
            user_txt.ForeColor = Color.FromArgb(226, 183, 141);

            
            picpass.BackgroundImage = Project06.Properties.Resources.Lock02;
            panel2.BackColor = Color.WhiteSmoke;
            Email_txt.ForeColor = Color.WhiteSmoke;

            
            picemail.BackgroundImage = Project06.Properties.Resources.Mail02;
            panel3.BackColor = Color.WhiteSmoke;
            Pass_txt.ForeColor = Color.WhiteSmoke;

        }

        private void textBox2_Click(object sender, EventArgs e)
        {
            Email_txt.Clear();
            picemail.BackgroundImage = Project06.Properties.Resources.mail01;
            panel2.BackColor = Color.FromArgb(226, 183, 141);
            Email_txt.ForeColor = Color.FromArgb(226, 183, 141);


            picuser.BackgroundImage = Project06.Properties.Resources.profile02;
            panel1.BackColor = Color.WhiteSmoke;
            user_txt.ForeColor = Color.WhiteSmoke;

            
            picpass.BackgroundImage = Project06.Properties.Resources.Lock02;
            panel3.BackColor = Color.WhiteSmoke;
            Pass_txt.ForeColor = Color.WhiteSmoke;


        }

        private void textBox3_Click(object sender, EventArgs e)
        {
            Pass_txt.Clear();
            Pass_txt.PasswordChar = '*';
            picpass.BackgroundImage = Project06.Properties.Resources.Lock01;
            panel3.BackColor = Color.FromArgb(226, 183, 141);
            Pass_txt.ForeColor = Color.FromArgb(226, 183, 141);


            picuser.BackgroundImage = Project06.Properties.Resources.profile02;
            panel1.BackColor = Color.WhiteSmoke;
            user_txt.ForeColor = Color.WhiteSmoke;


            picemail.BackgroundImage = Project06.Properties.Resources.Mail02;
            panel2.BackColor = Color.WhiteSmoke;
            Email_txt.ForeColor = Color.WhiteSmoke;

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void picface_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            frm2.Left += 10;
            if (frm2.Left >= 830)
            {
                timer1.Stop();
                this.TopMost = false;
                frm2.TopMost = true;
                timer2.Start();
            }

        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            frm2.Left -= 10;
            if (frm2.Left <= 525)
            {
                timer2.Stop();
            }

        }

        private void picgoog_Click(object sender, EventArgs e)
        {
            timer3.Start();
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            frm3.Left += 10;
            if (frm3.Left >= 830)
            {
                timer3.Stop();
                this.TopMost = false;
                frm3.TopMost = true;
                timer4.Start();
            }

        }

        private void timer4_Tick(object sender, EventArgs e)
        {
            frm3.Left -= 10;
            if (frm3.Left <= 525)
            {
                timer4.Stop();
            }

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            timer5.Start();

        }

        private void timer5_Tick(object sender, EventArgs e)
        {
            frm4.Left += 10;
            if (frm4.Left >= 830)
            {
                timer5.Stop();
                this.TopMost = false;
                frm4.TopMost = true;
                timer6.Start();
            }

        }

        private void timer6_Tick(object sender, EventArgs e)
        {
            frm4.Left -= 10;
            if (frm4.Left <= 525)
            {
                timer6.Stop();
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-L0DRGMJ;Initial Catalog=GuestHouseDB;Integrated Security=True");
        private void button1_Click(object sender, EventArgs e)
        {
            if(user_txt.Text == "" || Pass_txt.Text == "")
            {
                MessageBox.Show("Enter UserName and Password");
            }
            else
            {
                try
                {
                    con.Open();
                    SqlDataAdapter sda = new SqlDataAdapter("select Count(*) from UserTbl Where UserName='" +user_txt.Text+ "' and UserPass='" +Pass_txt.Text+ "'", con);
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    if(dt.Rows[0][0].ToString() == "1")
                    {
                        Dashboard obj = new Dashboard();
                        obj.Show();
                        this.Hide();
                        con.Close();
                    }
                    else
                    {
                        MessageBox.Show("Wrong UserName And Password");
                    }
                    con.Close();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Users obj = new Users();
            obj.Show();
            this.Hide();
        }

        

        

        
    }
}
