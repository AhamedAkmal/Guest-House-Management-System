﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Data.SqlClient;
using System.Data.Sql;

namespace Project06
{
    public partial class Users : Form
    {
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]

        private static extern IntPtr CreateRoundRectrgn
(
int nLeftReact,
int nTopReact,
int nRightReact,
int nBottomReact,
int nWidthEllipse,
int nHeightEllipse
);
        public Users()
        {
            InitializeComponent();
            ShowUsers();

            Region = System.Drawing.Region.FromHrgn(CreateRoundRectrgn(0, 0, Width, Height, 25, 25));
            pnlnav.Height = btnuser.Height;
            pnlnav.Top = btnuser.Top;
            pnlnav.Left = btnuser.Left;
            btnuser.BackColor = Color.FromArgb(44, 51, 73);
        }

        private void pictureBox12_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox11_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {

        }

        private void btndashboard_Click(object sender, EventArgs e)
        {
            pnlnav.Height = btndashboard.Height;
            pnlnav.Top = btndashboard.Top;
            pnlnav.Left = btndashboard.Left;
            btndashboard.BackColor = Color.FromArgb(44, 51, 73);

            
            Dashboard obj = new Dashboard();
            obj.Show();
            this.Hide();
        }

        private void btnuser_Click(object sender, EventArgs e)
        {
            pnlnav.Height = btnuser.Height;
            pnlnav.Top = btnuser.Top;
            btnuser.BackColor = Color.FromArgb(44, 51, 73);

            
            Users obj = new Users();
            obj.Show();
            this.Hide();

        }

        private void btncustomer_Click(object sender, EventArgs e)
        {
            pnlnav.Height = btncustomer.Height;
            pnlnav.Top = btncustomer.Top;
            btncustomer.BackColor = Color.FromArgb(44, 51, 73);

            
            Customer obj = new Customer();
            obj.Show();
            this.Hide();
        }

        private void btnbooking_Click(object sender, EventArgs e)
        {
            pnlnav.Height = btnbooking.Height;
            pnlnav.Top = btnbooking.Top;
            btnbooking.BackColor = Color.FromArgb(44, 51, 73);

           
            Bookings obj = new Bookings();
            obj.Show();
            this.Hide();
        }

        private void btnlogout_Click(object sender, EventArgs e)
        {
            pnlnav.Height = btnlogout.Height;
            pnlnav.Top = btnlogout.Top;
            btnlogout.BackColor = Color.FromArgb(44, 51, 73);

            
            frm_login obj = new frm_login();
            obj.Show();
            this.Hide();
        }

        private void btndashboard_Leave(object sender, EventArgs e)
        {
            btndashboard.BackColor = Color.FromArgb(24, 30, 54);
        }

        private void btnuser_Leave(object sender, EventArgs e)
        {
            btnuser.BackColor = Color.FromArgb(24, 30, 54);
        }

        private void btncustomer_Leave(object sender, EventArgs e)
        {
            btncustomer.BackColor = Color.FromArgb(24, 30, 54);
        }

        private void btnbooking_Leave(object sender, EventArgs e)
        {
            btnbooking.BackColor = Color.FromArgb(24, 30, 54);
        }

        private void btnlogout_Leave(object sender, EventArgs e)
        {
            btnlogout.BackColor = Color.FromArgb(24, 30, 54);
        }

        private void Users_Load(object sender, EventArgs e)
        {

        }

        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-L0DRGMJ;Initial Catalog=GuestHouseDB;Integrated Security=True");
        private void ShowUsers()
        {
            con.Open();
            string Query = "Select * From Usertbl";
            SqlDataAdapter sda = new SqlDataAdapter(Query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            UserDGV.DataSource = ds.Tables[0];
            con.Close();
        }




        private void btn_save_Click(object sender, EventArgs e)
        {
            if (Usernametb.Text == "" || Uphonetb.Text == "" || Upasstb.Text == "")
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("insert into Usertbl(UserName,UserPhone,UserPass)values(@UN,@UP,@UPA)", con);
                    cmd.Parameters.AddWithValue("@UN", Usernametb.Text);
                    cmd.Parameters.AddWithValue("@UP", Uphonetb.Text);
                    cmd.Parameters.AddWithValue("@UPA", Upasstb.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("User Saved");
                    con.Close();
                    ShowUsers();
                    Reset();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }
        int Key = 0;
        private void UserDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            Usernametb.Text = UserDGV.SelectedRows[0].Cells[1].Value.ToString();
            Uphonetb.Text = UserDGV.SelectedRows[0].Cells[2].Value.ToString();
            Upasstb.Text = UserDGV.SelectedRows[0].Cells[3].Value.ToString();
            if (Usernametb.Text == "")
            {
                Key = 0;
            }
            else
            {
                Key = Convert.ToInt32(UserDGV.SelectedRows[0].Cells[0].Value.ToString());
            }

        }

        private void btn_edit_Click(object sender, EventArgs e)
        {
            if (Usernametb.Text == "" || Uphonetb.Text == "" || Upasstb.Text == "")
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("Update Usertbl Set UserName=@UN,UserPhone=@UP,UserPass=@UPA Where UserID=@UKey", con);
                    cmd.Parameters.AddWithValue("@UN", Usernametb.Text);
                    cmd.Parameters.AddWithValue("@UP", Uphonetb.Text);
                    cmd.Parameters.AddWithValue("@UPA", Upasstb.Text);
                    cmd.Parameters.AddWithValue("@UKey", Key);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("User Updated");
                    con.Close();
                    ShowUsers();
                    Reset();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }
        private void Reset()
        {
            Usernametb.Text = "";
            Uphonetb.Text = "";
            Upasstb.Text = "";
            Key = 0;
        }
        private void btn_delete_Click(object sender, EventArgs e)
        {
            {
                if (Key == 0)
                {
                    MessageBox.Show("Select User");
                }
                else
                {
                    try
                    {
                        con.Open();
                        SqlCommand cmd = new SqlCommand("Delete From Usertbl Where UserId=@UKey", con);
                        cmd.Parameters.AddWithValue("@UKey", Key);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("User Deleted");
                        con.Close();
                        ShowUsers();
                        Reset();
                    }
                    catch (Exception Ex)
                    {
                        MessageBox.Show(Ex.Message);
                    }
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
